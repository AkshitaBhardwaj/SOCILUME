import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// This would be replaced with your actual email service integration
// like SendGrid, Mailgun, AWS SES, etc.
const sendEmail = async (data: any) => {
  // Simulate API call for demonstration
  await new Promise(resolve => setTimeout(resolve, 500));
  // In a real implementation, you would send the email here
  console.log('Sending email with data:', data);
  return { success: true };
};

// Contact form handler
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Required fields validation
    const { name, email, subject, message } = body;
    
    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }
    
    // Process contact request
    await sendEmail({
      to: 'contact@SociLume.com',  // Replace with your business email
      from: email,
      subject: subject || `New Contact Form Submission from ${name}`,
      text: message,
      name,
    });
    
    // Return success response
    return NextResponse.json({
      success: true,
      message: 'Thank you! Your message has been received.'
    });
    
  } catch (error) {
    console.error('Contact form error:', error);
    return NextResponse.json(
      { error: 'Failed to submit contact form' },
      { status: 500 }
    );
  }
} 