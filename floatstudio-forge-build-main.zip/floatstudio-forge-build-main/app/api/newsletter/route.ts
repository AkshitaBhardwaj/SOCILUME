import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// This would be replaced with your actual email service or CRM integration
// like Mailchimp, ConvertKit, HubSpot, etc.
const subscribeToNewsletter = async (email: string) => {
  // Simulate API call for demonstration
  await new Promise(resolve => setTimeout(resolve, 500));
  // In a real implementation, you would add the email to your mailing list
  console.log('Subscribing email to newsletter:', email);
  return { success: true };
};

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Required fields validation
    const { email } = body;
    
    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }
    
    // Process newsletter subscription
    await subscribeToNewsletter(email);
    
    // Return success response
    return NextResponse.json({
      success: true,
      message: 'Thank you for subscribing to our newsletter!'
    });
    
  } catch (error) {
    console.error('Newsletter subscription error:', error);
    return NextResponse.json(
      { error: 'Failed to subscribe to newsletter' },
      { status: 500 }
    );
  }
} 