import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Sample project data - in a real app this would come from a database
const projects = [
  {
    id: "1",
    title: "SocyU AI Platform",
    description: "A platform to manage marketing for you.",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070",
    category: "webapp",
    technologies: ["Next.js", "TypeScript", "TailwindCSS", "MongoDB"],
    link: "https://socyu.com",
    featured: true
  },
  {
    id: "2",
    title: "RentAra Property Management",
    description: "A comprehensive rental management tool that streamlines property management, rent collection, and tenant communications.",
    image: "https://images.unsplash.com/photo-1560185127-6ed189bf02f4?q=80&w=2070",
    category: "webapp",
    technologies: ["React", "Node.js", "Express", "MongoDB"],
    link: "https://www.rentara.in",
    featured: true
  },
  {
    id: "3",
    title: "Babbars Export Import",
    description: "A professional website for Babbars Export Import, showcasing their services and facilitating client engagement.",
    image: "https://images.unsplash.com/photo-1581090700227-1e8e5f1a6d5c?q=80&w=2070",
    category: "website",
    technologies: ["HTML", "CSS", "JavaScript", "Bootstrap"],
    link: "https://babbarexportimport.in",
    featured: false
  },
  {
    id: "4",
    title: "Focus Fuel Flow",
    description: "A productivity tool designed to enhance focus and efficiency through structured workflows and task management.",
    image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=2070",
    category: "webapp",
    technologies: ["Vue.js", "Firebase", "TailwindCSS"],
    link: "https://preview--focus-fuel-flow.lovable.app/",
    featured: false
  },
  {
    id: "5",
    title: "RentARobot Assistant",
    description: "An AI-powered assistant platform offering robotic solutions for various applications, enhancing automation and efficiency.",
    image: "https://images.unsplash.com/photo-1581090700227-1e8e5f1a6d5c?q=80&w=2070",
    category: "webapp",
    technologies: ["React", "Node.js", "Express", "MongoDB"],
    link: "https://preview--rentarobot-assistant.lovable.app/",
    featured: false
  },
  {
    id: "6",
    title: "Content Sharer Hub",
    description: "A centralized platform for content creators to share, manage, and collaborate on various media projects.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2070",
    category: "webapp",
    technologies: ["Next.js", "TypeScript", "TailwindCSS", "Firebase"],
    link: "https://preview--content-sharer-hub.lovable.app/",
    featured: false
  }
];


export async function GET(request: Request) {
  try {
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const featured = searchParams.get('featured');
    const limit = searchParams.get('limit');
    
    let filteredProjects = [...projects];
    
    // Apply category filter
    if (category && category !== 'all') {
      filteredProjects = filteredProjects.filter(
        project => project.category === category
      );
    }
    
    // Apply featured filter
    if (featured === 'true') {
      filteredProjects = filteredProjects.filter(
        project => project.featured
      );
    }
    
    // Apply limit
    if (limit) {
      filteredProjects = filteredProjects.slice(0, parseInt(limit));
    }
    
    // Return filtered projects
    return NextResponse.json({
      success: true,
      data: filteredProjects
    });
    
  } catch (error) {
    console.error('Projects API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch projects' },
      { status: 500 }
    );
  }
} 