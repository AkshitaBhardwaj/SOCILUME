import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Generate robots.txt content
  const robotsTxt = `# robots.txt for SociLume
# Main rules for all crawlers
User-agent: *
Allow: /
Allow: /sitemap.xml
Allow: /images/
Allow: /css/
Allow: /js/

# Disallow specific directories and files
Disallow: /api/
Disallow: /_next/
Disallow: /admin/
Disallow: /dashboard/
Disallow: /private/
Disallow: /temp/
Disallow: /drafts/
Disallow: /*.json$
Disallow: /*?*fbclid=
Disallow: /*?*utm_source=
Disallow: /*?*utm_medium=
Disallow: /*?*utm_campaign=

# Special rules for specific bots

# Google specific
User-agent: Googlebot
Allow: /
Crawl-delay: 1

# Google Image specific
User-agent: Googlebot-Image
Allow: /images/
Allow: /assets/
Allow: /public/

# Bing specific
User-agent: Bingbot
Allow: /
Crawl-delay: 2

# Yandex specific
User-agent: Yandex
Allow: /
Crawl-delay: 2

# Sitemaps
Sitemap: ${domain}/sitemap.xml
Sitemap: ${domain}/sitemap-blog.xml
Sitemap: ${domain}/sitemap-services.xml
Sitemap: ${domain}/sitemap-locations.xml

# Host directive for canonical domain
Host: ${domain}
`;
  
  // Return text response
  return new NextResponse(robotsTxt, {
    headers: {
      'Content-Type': 'text/plain',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 