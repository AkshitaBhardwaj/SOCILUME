import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Blog sitemap generator for better SEO of content
export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Sample blog posts with detailed information
  // In a real implementation, this would be fetched from a database or CMS
  const blogPosts = [
    {
      slug: 'website-cost-guide',
      title: 'How Much Should a Small Business Website Cost in 2025?',
      lastmod: '2025-01-15',
      changefreq: 'monthly',
      priority: 0.8,
      images: [
        {
          url: `${domain}/images/blog/website-cost-guide.jpg`,
          title: 'Website Cost Guide for Small Businesses',
          caption: 'Breakdown of website costs for small businesses in 2025'
        }
      ]
    },
    {
      slug: 'ai-marketing-tools',
      title: '10 AI Marketing Tools Every Small Business Should Use',
      lastmod: '2025-01-10',
      changefreq: 'monthly',
      priority: 0.8,
      images: [
        {
          url: `${domain}/images/blog/ai-marketing-tools.jpg`,
          title: 'AI Marketing Tools for Small Business',
          caption: 'Top AI marketing tools for small business growth'
        }
      ]
    },
    {
      slug: 'small-business-website-tips',
      title: '7 Essential Features Every Small Business Website Needs',
      lastmod: '2025-01-05',
      changefreq: 'monthly',
      priority: 0.7,
      images: [
        {
          url: `${domain}/images/blog/small-business-website-tips.jpg`,
          title: 'Small Business Website Features',
          caption: 'Essential features for effective small business websites'
        }
      ]
    },
    {
      slug: 'seo-for-beginners',
      title: 'SEO for Beginners: How to Get Your Website Found',
      lastmod: '2024-12-20',
      changefreq: 'monthly',
      priority: 0.7,
      images: [
        {
          url: `${domain}/images/blog/seo-for-beginners.jpg`,
          title: 'SEO for Beginners Guide',
          caption: 'Simple SEO strategies for new website owners'
        }
      ]
    },
    {
      slug: 'social-media-automation',
      title: 'How to Automate Your Social Media with AI',
      lastmod: '2024-12-15',
      changefreq: 'monthly',
      priority: 0.7,
      images: [
        {
          url: `${domain}/images/blog/social-media-automation.jpg`,
          title: 'Social Media Automation with AI',
          caption: 'Using AI to automate your social media marketing'
        }
      ]
    },
    {
      slug: 'website-conversion-tips',
      title: '5 Ways to Increase Your Website Conversion Rate',
      lastmod: '2024-12-10',
      changefreq: 'monthly',
      priority: 0.7,
      images: [
        {
          url: `${domain}/images/blog/website-conversion-tips.jpg`,
          title: 'Website Conversion Tips',
          caption: 'Strategies to improve your website conversion rate'
        }
      ]
    },
    {
      slug: 'mobile-optimization-guide',
      title: 'Mobile Optimization: Why It Matters for Your Business',
      lastmod: '2024-12-05',
      changefreq: 'monthly',
      priority: 0.7,
      images: [
        {
          url: `${domain}/images/blog/mobile-optimization-guide.jpg`,
          title: 'Mobile Optimization Guide',
          caption: 'Making your website mobile-friendly for better results'
        }
      ]
    },
    {
      slug: 'content-marketing-strategies',
      title: 'Content Marketing Strategies That Actually Work',
      lastmod: '2024-11-30',
      changefreq: 'monthly',
      priority: 0.7,
      images: [
        {
          url: `${domain}/images/blog/content-marketing-strategies.jpg`,
          title: 'Content Marketing Strategies',
          caption: 'Effective content marketing approaches for businesses'
        }
      ]
    }
  ];
  
  // Generate XML content
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">\n';
  
  // Add blog posts to sitemap
  blogPosts.forEach(post => {
    xml += '  <url>\n';
    xml += `    <loc>${domain}/blog/${post.slug}</loc>\n`;
    xml += `    <lastmod>${post.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${post.changefreq}</changefreq>\n`;
    xml += `    <priority>${post.priority}</priority>\n`;
    
    // Add news tag for recent articles (within 2 days)
    const twoWeeksAgo = new Date();
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
    const postDate = new Date(post.lastmod);
    
    if (postDate > twoWeeksAgo) {
      xml += '    <news:news>\n';
      xml += '      <news:publication>\n';
      xml += '        <news:name>SociLume Blog</news:name>\n';
      xml += '        <news:language>en</news:language>\n';
      xml += '      </news:publication>\n';
      xml += `      <news:publication_date>${post.lastmod}</news:publication_date>\n`;
      xml += `      <news:title>${post.title}</news:title>\n`;
      xml += '    </news:news>\n';
    }
    
    // Add images
    if (post.images && post.images.length > 0) {
      post.images.forEach(image => {
        xml += '    <image:image>\n';
        xml += `      <image:loc>${image.url}</image:loc>\n`;
        xml += `      <image:title>${image.title}</image:title>\n`;
        xml += `      <image:caption>${image.caption}</image:caption>\n`;
        xml += '    </image:image>\n';
      });
    }
    
    xml += '  </url>\n';
  });
  
  xml += '</urlset>';
  
  // Return XML with correct content type
  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 