import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Sitemap index generator for organizing multiple sitemaps
export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Current date for lastmod
  const today = new Date().toISOString().split('T')[0];
  
  // List of all sitemaps
  const sitemaps = [
    { path: 'sitemap.xml', lastmod: today },
    { path: 'sitemap-blog.xml', lastmod: today },
    { path: 'sitemap-services.xml', lastmod: today },
    { path: 'sitemap-locations.xml', lastmod: today },
    { path: 'sitemap-industries.xml', lastmod: today },
  ];
  
  // Generate XML content
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  
  // Add sitemaps to index
  sitemaps.forEach(sitemap => {
    xml += '  <sitemap>\n';
    xml += `    <loc>${domain}/${sitemap.path}</loc>\n`;
    xml += `    <lastmod>${sitemap.lastmod}</lastmod>\n`;
    xml += '  </sitemap>\n';
  });
  
  xml += '</sitemapindex>';
  
  // Return XML with correct content type
  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 