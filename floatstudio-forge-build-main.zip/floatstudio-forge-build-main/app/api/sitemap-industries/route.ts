import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Industry-specific sitemap generator for targeted SEO
export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Current date for lastmod
  const today = new Date().toISOString().split('T')[0];
  
  // List of industries with specific data
  const industries = [
    {
      slug: 'restaurants',
      name: 'Restaurant & Food Service',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      features: ['online-ordering', 'menu-display', 'reservation-system']
    },
    {
      slug: 'real-estate',
      name: 'Real Estate',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      features: ['property-listings', 'virtual-tours', 'agent-profiles']
    },
    {
      slug: 'healthcare',
      name: 'Healthcare & Medical',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      features: ['appointment-booking', 'patient-portal', 'telehealth']
    },
    {
      slug: 'professional-services',
      name: 'Professional Services',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      features: ['appointment-scheduling', 'client-portal', 'case-studies']
    },
    {
      slug: 'ecommerce',
      name: 'E-commerce & Retail',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      features: ['product-catalog', 'shopping-cart', 'payment-processing']
    },
    {
      slug: 'fitness',
      name: 'Fitness & Wellness',
      priority: 0.7,
      changefreq: 'monthly',
      lastmod: today,
      features: ['class-scheduling', 'membership-management', 'virtual-classes']
    },
    {
      slug: 'education',
      name: 'Education & Learning',
      priority: 0.7,
      changefreq: 'monthly',
      lastmod: today,
      features: ['course-catalog', 'student-portal', 'online-learning']
    },
    {
      slug: 'home-services',
      name: 'Home Services',
      priority: 0.7,
      changefreq: 'monthly',
      lastmod: today,
      features: ['service-booking', 'quote-requests', 'portfolio-gallery']
    }
  ];
  
  // Generate XML content
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  
  // Add industry pages to sitemap
  industries.forEach(industry => {
    xml += '  <url>\n';
    xml += `    <loc>${domain}/industries/${industry.slug}</loc>\n`;
    xml += `    <lastmod>${industry.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${industry.changefreq}</changefreq>\n`;
    xml += `    <priority>${industry.priority}</priority>\n`;
    xml += '  </url>\n';
    
    // Add industry-specific feature pages
    industry.features.forEach(feature => {
      xml += '  <url>\n';
      xml += `    <loc>${domain}/industries/${industry.slug}/${feature}</loc>\n`;
      xml += `    <lastmod>${industry.lastmod}</lastmod>\n`;
      xml += `    <changefreq>${industry.changefreq}</changefreq>\n`;
      xml += `    <priority>${industry.priority - 0.1}</priority>\n`;
      xml += '  </url>\n';
    });
    
    // Add industry-specific case studies
    xml += '  <url>\n';
    xml += `    <loc>${domain}/industries/${industry.slug}/case-studies</loc>\n`;
    xml += `    <lastmod>${industry.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${industry.changefreq}</changefreq>\n`;
    xml += `    <priority>${industry.priority - 0.1}</priority>\n`;
    xml += '  </url>\n';
  });
  
  xml += '</urlset>';
  
  // Return XML with correct content type
  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 