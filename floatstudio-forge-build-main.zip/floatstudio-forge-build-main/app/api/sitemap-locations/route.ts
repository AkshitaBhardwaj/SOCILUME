import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Location sitemap generator for local SEO
export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Current date for lastmod
  const today = new Date().toISOString().split('T')[0];
  
  // List of locations with geo data
  const locations = [
    {
      slug: 'san-francisco',
      name: 'San Francisco',
      state: 'CA',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 37.7749,
        lng: -122.4194
      }
    },
    {
      slug: 'new-york',
      name: 'New York',
      state: 'NY',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 40.7128,
        lng: -74.0060
      }
    },
    {
      slug: 'los-angeles',
      name: 'Los Angeles',
      state: 'CA',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 34.0522,
        lng: -118.2437
      }
    },
    {
      slug: 'chicago',
      name: 'Chicago',
      state: 'IL',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 41.8781,
        lng: -87.6298
      }
    },
    {
      slug: 'miami',
      name: 'Miami',
      state: 'FL',
      priority: 0.8,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 25.7617,
        lng: -80.1918
      }
    },
    {
      slug: 'seattle',
      name: 'Seattle',
      state: 'WA',
      priority: 0.7,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 47.6062,
        lng: -122.3321
      }
    },
    {
      slug: 'austin',
      name: 'Austin',
      state: 'TX',
      priority: 0.7,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 30.2672,
        lng: -97.7431
      }
    },
    {
      slug: 'denver',
      name: 'Denver',
      state: 'CO',
      priority: 0.7,
      changefreq: 'monthly',
      lastmod: today,
      geo: {
        lat: 39.7392,
        lng: -104.9903
      }
    }
  ];
  
  // Generate XML content
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:geo="http://www.google.com/geo/schemas/sitemap/1.0">\n';
  
  // Add location pages to sitemap
  locations.forEach(location => {
    xml += '  <url>\n';
    xml += `    <loc>${domain}/locations/${location.slug}</loc>\n`;
    xml += `    <lastmod>${location.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${location.changefreq}</changefreq>\n`;
    xml += `    <priority>${location.priority}</priority>\n`;
    
    // Add geo information
    if (location.geo) {
      xml += '    <geo:geo>\n';
      xml += '      <geo:format>kml</geo:format>\n';
      xml += `      <geo:point>\n`;
      xml += `        <geo:lat>${location.geo.lat}</geo:lat>\n`;
      xml += `        <geo:lng>${location.geo.lng}</geo:lng>\n`;
      xml += `      </geo:point>\n`;
      xml += '    </geo:geo>\n';
    }
    
    xml += '  </url>\n';
    
    // Add location-specific service pages
    const services = ['website-design', 'ai-marketing', 'ecommerce', 'seo-optimization'];
    services.forEach(service => {
      xml += '  <url>\n';
      xml += `    <loc>${domain}/locations/${location.slug}/${service}</loc>\n`;
      xml += `    <lastmod>${location.lastmod}</lastmod>\n`;
      xml += `    <changefreq>${location.changefreq}</changefreq>\n`;
      xml += `    <priority>${location.priority - 0.1}</priority>\n`;
      xml += '  </url>\n';
    });
  });
  
  xml += '</urlset>';
  
  // Return XML with correct content type
  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 