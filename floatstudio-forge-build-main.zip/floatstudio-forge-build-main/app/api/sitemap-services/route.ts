import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Services sitemap generator for better SEO of service offerings
export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Current date for lastmod
  const today = new Date().toISOString().split('T')[0];
  
  // List of services with detailed information
  const services = [
    {
      slug: 'website-design',
      title: 'Professional Website Design',
      description: 'Custom website design services for businesses of all sizes.',
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.9,
      subpages: [
        { slug: 'landing-pages', title: 'Landing Page Design', priority: 0.8 },
        { slug: 'ecommerce-design', title: 'E-commerce Website Design', priority: 0.8 },
        { slug: 'portfolio-sites', title: 'Portfolio Website Design', priority: 0.7 },
        { slug: 'business-websites', title: 'Business Website Design', priority: 0.8 }
      ]
    },
    {
      slug: 'ai-marketing',
      title: 'AI Marketing Solutions',
      description: 'Automated marketing solutions powered by artificial intelligence.',
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.9,
      subpages: [
        { slug: 'content-generation', title: 'AI Content Generation', priority: 0.8 },
        { slug: 'social-media-automation', title: 'Social Media Automation', priority: 0.8 },
        { slug: 'campaign-management', title: 'AI Campaign Management', priority: 0.8 },
        { slug: 'influencer-matching', title: 'AI Influencer Matching', priority: 0.7 }
      ]
    },
    {
      slug: 'ecommerce',
      title: 'E-commerce Solutions',
      description: 'Complete e-commerce website development and management.',
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.8,
      subpages: [
        { slug: 'online-stores', title: 'Online Store Development', priority: 0.7 },
        { slug: 'product-catalog', title: 'Product Catalog Management', priority: 0.7 },
        { slug: 'payment-processing', title: 'Payment Processing Integration', priority: 0.7 },
        { slug: 'inventory-management', title: 'Inventory Management Systems', priority: 0.7 }
      ]
    },
    {
      slug: 'landing-pages',
      title: 'High-Converting Landing Pages',
      description: 'Specialized landing pages designed to convert visitors into customers.',
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.8,
      subpages: [
        { slug: 'sales-pages', title: 'Sales Landing Pages', priority: 0.7 },
        { slug: 'lead-generation', title: 'Lead Generation Pages', priority: 0.7 },
        { slug: 'event-pages', title: 'Event Landing Pages', priority: 0.7 },
        { slug: 'product-launch', title: 'Product Launch Pages', priority: 0.7 }
      ]
    },
    {
      slug: 'seo-optimization',
      title: 'SEO Optimization Services',
      description: 'Comprehensive search engine optimization for better visibility.',
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.8,
      subpages: [
        { slug: 'local-seo', title: 'Local SEO Services', priority: 0.7 },
        { slug: 'technical-seo', title: 'Technical SEO Audits', priority: 0.7 },
        { slug: 'content-optimization', title: 'Content SEO Optimization', priority: 0.7 },
        { slug: 'keyword-research', title: 'Keyword Research & Strategy', priority: 0.7 }
      ]
    },
    {
      slug: 'social-media-management',
      title: 'Social Media Management',
      description: 'Complete social media management and growth services.',
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.8,
      subpages: [
        { slug: 'content-creation', title: 'Social Media Content Creation', priority: 0.7 },
        { slug: 'community-management', title: 'Community Management', priority: 0.7 },
        { slug: 'paid-social', title: 'Paid Social Advertising', priority: 0.7 },
        { slug: 'analytics-reporting', title: 'Social Media Analytics', priority: 0.7 }
      ]
    }
  ];
  
  // Generate XML content
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  
  // Add service pages to sitemap
  services.forEach(service => {
    // Main service page
    xml += '  <url>\n';
    xml += `    <loc>${domain}/services/${service.slug}</loc>\n`;
    xml += `    <lastmod>${service.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${service.changefreq}</changefreq>\n`;
    xml += `    <priority>${service.priority}</priority>\n`;
    xml += '  </url>\n';
    
    // Service subpages
    service.subpages.forEach(subpage => {
      xml += '  <url>\n';
      xml += `    <loc>${domain}/services/${service.slug}/${subpage.slug}</loc>\n`;
      xml += `    <lastmod>${service.lastmod}</lastmod>\n`;
      xml += `    <changefreq>${service.changefreq}</changefreq>\n`;
      xml += `    <priority>${subpage.priority}</priority>\n`;
      xml += '  </url>\n';
    });
    
    // Add pricing page for each service
    xml += '  <url>\n';
    xml += `    <loc>${domain}/services/${service.slug}/pricing</loc>\n`;
    xml += `    <lastmod>${service.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${service.changefreq}</changefreq>\n`;
    xml += `    <priority>${service.priority - 0.1}</priority>\n`;
    xml += '  </url>\n';
    
    // Add FAQ page for each service
    xml += '  <url>\n';
    xml += `    <loc>${domain}/services/${service.slug}/faq</loc>\n`;
    xml += `    <lastmod>${service.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${service.changefreq}</changefreq>\n`;
    xml += `    <priority>${service.priority - 0.1}</priority>\n`;
    xml += '  </url>\n';
  });
  
  xml += '</urlset>';
  
  // Return XML with correct content type
  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 