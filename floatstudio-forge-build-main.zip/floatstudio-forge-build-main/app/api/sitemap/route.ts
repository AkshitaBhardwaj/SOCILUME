import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Dynamic sitemap generator for SEO optimization
export async function GET() {
  // Base domain - replace with the actual domain in production
  const domain = 'https://socilume.com';
  
  // Current date for lastmod
  const today = new Date().toISOString().split('T')[0];
  
  // List of all pages on the site with their priorities and change frequencies
  const pages = [
    // Core pages
    { path: '', priority: 1.0, changefreq: 'weekly', lastmod: today },
    { path: 'about', priority: 0.8, changefreq: 'monthly', lastmod: today },
    { path: 'services', priority: 0.9, changefreq: 'monthly', lastmod: today },
    { path: 'portfolio', priority: 0.8, changefreq: 'weekly', lastmod: today },
    { path: 'contact', priority: 0.8, changefreq: 'monthly', lastmod: today },
    { path: 'pricing', priority: 0.9, changefreq: 'weekly', lastmod: today },
    
    // Legal pages
    { path: 'legal', priority: 0.5, changefreq: 'monthly', lastmod: today },
    { path: 'privacy-policy', priority: 0.5, changefreq: 'monthly', lastmod: today },
    { path: 'terms-of-service', priority: 0.5, changefreq: 'monthly', lastmod: today },
    { path: 'cookie-policy', priority: 0.5, changefreq: 'monthly', lastmod: today },
    { path: 'sitemap', priority: 0.3, changefreq: 'monthly', lastmod: today },
    
    // Blog and content pages
    { path: 'blog', priority: 0.7, changefreq: 'weekly', lastmod: today },
    { path: 'blog/website-cost-guide', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'blog/ai-marketing-tools', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'blog/small-business-website-tips', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'blog/seo-for-beginners', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'blog/social-media-automation', priority: 0.7, changefreq: 'monthly', lastmod: today },
    
    // Service pages
    { path: 'services/website-design', priority: 0.8, changefreq: 'monthly', lastmod: today },
    { path: 'services/ai-marketing', priority: 0.8, changefreq: 'monthly', lastmod: today },
    { path: 'services/ecommerce', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'services/landing-pages', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'services/seo-optimization', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'services/social-media-management', priority: 0.7, changefreq: 'monthly', lastmod: today },
    
    // Tools pages
    { path: 'tools/bio-generator', priority: 0.6, changefreq: 'monthly', lastmod: today },
    { path: 'tools/marketing-calculator', priority: 0.6, changefreq: 'monthly', lastmod: today },
    { path: 'tools/seo-analyzer', priority: 0.6, changefreq: 'monthly', lastmod: today },
    
    // Location pages for local SEO
    { path: 'locations/san-francisco', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'locations/new-york', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'locations/los-angeles', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'locations/chicago', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'locations/miami', priority: 0.7, changefreq: 'monthly', lastmod: today },
    
    // Industry-specific pages
    { path: 'industries/restaurants', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'industries/real-estate', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'industries/healthcare', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'industries/professional-services', priority: 0.7, changefreq: 'monthly', lastmod: today },
    { path: 'industries/ecommerce', priority: 0.7, changefreq: 'monthly', lastmod: today },
  ];
  
  // Generate XML content
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n';
  
  // Add pages to sitemap
  pages.forEach(page => {
    xml += '  <url>\n';
    xml += `    <loc>${domain}/${page.path}</loc>\n`;
    xml += `    <lastmod>${page.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${page.changefreq}</changefreq>\n`;
    xml += `    <priority>${page.priority}</priority>\n`;
    
    // Add hreflang tags for multilingual support
    if (page.path === '' || page.path === 'about' || page.path === 'services' || page.path === 'contact') {
      xml += `    <xhtml:link rel="alternate" hreflang="en" href="${domain}/${page.path}" />\n`;
      xml += `    <xhtml:link rel="alternate" hreflang="es" href="${domain}/es/${page.path}" />\n`;
    }
    
    xml += '  </url>\n';
  });
  
  xml += '</urlset>';
  
  // Return XML with correct content type
  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
} 