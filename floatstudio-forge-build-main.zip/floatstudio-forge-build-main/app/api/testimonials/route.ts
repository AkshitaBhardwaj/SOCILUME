import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

// Sample testimonial data - in a real app this would come from a database
const testimonials = [
  {
    id: "1",
    name: "Sarah Johnson",
    role: "CEO",
    company: "Zenith Enterprises",
    content: "SociLume transformed our online presence completely. The team delivered a website that's not just beautiful but also performs exceptionally well. Our conversion rates have increased by 45% since launch.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1974",
    featured: true
  },
  {
    id: "2",
    name: "Michael Chen",
    role: "Marketing Director",
    company: "NexGen Solutions",
    content: "Working with SociLume was a game-changer for our brand. Their attention to detail and understanding of our market positioning led to a website that perfectly captures our vision and resonates with our audience.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974",
    featured: true
  },
  {
    id: "3",
    name: "Emma Rodriguez",
    role: "Founder",
    company: "Elysian Retreats",
    content: "The immersive experience SociLume created for our luxury travel platform has set us apart from competitors. The 3D elements and animations brought our vision to life in ways we couldn't have imagined.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=1976",
    featured: false
  },
  {
    id: "4",
    name: "James Wilson",
    role: "CTO",
    company: "Quantum Analytics",
    content: "As a tech company, we needed a partner who understood complex data visualization needs. SociLume exceeded our expectations, delivering an interface that makes complex data accessible and engaging for our users.",
    rating: 4,
    image: "https://images.unsplash.com/photo-1545167622-3a6ac756afa4?q=80&w=1912",
    featured: true
  },
  {
    id: "5",
    name: "Olivia Smith",
    role: "Creative Director",
    company: "Artisan Studios",
    content: "The design sensibility of the SociLume team is unmatched. They took our brand identity and elevated it with subtle animations and thoughtful interactions that feel premium yet intuitive.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?q=80&w=2071",
    featured: false
  },
  {
    id: "6",
    name: "David Park",
    role: "E-commerce Manager",
    company: "Urban Outfitters",
    content: "Our e-commerce conversion rates improved significantly after SociLume redesigned our product pages. The mobile experience in particular has received praise from our customers.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2070",
    featured: false
  }
];

export async function GET(request: Request) {
  try {
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const featured = searchParams.get('featured');
    const limit = searchParams.get('limit');
    
    let filteredTestimonials = [...testimonials];
    
    // Apply featured filter
    if (featured === 'true') {
      filteredTestimonials = filteredTestimonials.filter(
        testimonial => testimonial.featured
      );
    }
    
    // Apply limit
    if (limit) {
      filteredTestimonials = filteredTestimonials.slice(0, parseInt(limit));
    }
    
    // Return filtered testimonials
    return NextResponse.json({
      success: true,
      data: filteredTestimonials
    });
    
  } catch (error) {
    console.error('Testimonials API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch testimonials' },
      { status: 500 }
    );
  }
} 