import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const AboutUs = () => {
  // SEO-friendly data structure
  const aboutData = {
    title: "Pioneering Digital Excellence: Who We Are",
    paragraph1: "We are a collective of passionate designers, developers, and strategists dedicated to forging impactful digital solutions. Our mission is to empower businesses by creating sophisticated, high-performance websites that not only look stunning but also deliver tangible results.",
    paragraph2: "Leveraging the latest technologies, including the robust Next.js framework, we build future-proof platforms tailored to your unique brand identity and business objectives. We believe in a collaborative approach, working closely with you to turn innovative ideas into digital reality.",
    valuesTitle: "Our Core Principles",
    values: [
      {
        name: "Innovation",
        description: "Constantly exploring new technologies and creative approaches to deliver cutting-edge solutions."
      },
      {
        name: "Quality",
        description: "Upholding the highest standards in design, development, and performance for every project."
      },
      {
        name: "Partnership",
        description: "Building transparent and collaborative relationships with our clients for shared success."
      },
      {
        name: "Results-Driven",
        description: "Focusing on achieving measurable outcomes that contribute to your business growth."
      }
    ]
  };

  return (
    <div className="container mx-auto px-4 py-24" id="about-section">
      <h2 
        id="about-us-heading" 
        className="text-4xl font-bold text-center mb-12"
        itemProp="headline"
      >
        {aboutData.title}
      </h2>
      
      <div className="grid md:grid-cols-2 gap-12 mb-16">
        <div 
          className="prose lg:prose-xl max-w-none"
          itemProp="description"
        >
          <p className="text-lg mb-6 leading-relaxed">
            {aboutData.paragraph1}
          </p>
          <p className="text-lg leading-relaxed">
            {aboutData.paragraph2}
          </p>
        </div>
        
        <div className="flex items-center justify-center">
          <div className="relative w-full h-full max-w-md">
            {/* Image optimized for SEO with descriptive alt text */}
            <img 
              src="/about-team.jpg" 
              alt="SociLume's team of expert web developers and designers working collaboratively on Next.js projects" 
              className="rounded-lg shadow-lg object-cover" 
              width={600}
              height={400}
              loading="lazy"
              itemProp="image"
            />
            <div 
              className="absolute -bottom-6 -right-6 bg-gradient-to-r from-purple-600 to-blue-500 p-6 rounded-lg shadow-lg"
              aria-hidden="true"
            >
              <span className="text-white font-bold text-lg">10+ Years Experience</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-20">
        <h3 
          className="text-2xl font-bold text-center mb-12"
          itemProp="alternativeHeadline"
        >
          {aboutData.valuesTitle}
        </h3>
        
        <div 
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
          itemScope 
          itemType="https://schema.org/ItemList"
        >
          {aboutData.values.map((value, index) => (
            <Card 
              key={index} 
              className="border-0 shadow-lg hover:shadow-xl transition-shadow"
              itemProp="itemListElement" 
              itemScope 
              itemType="https://schema.org/ListItem"
            >
              <CardContent className="p-6">
                <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-600 text-xl font-bold">{index + 1}</span>
                </div>
                <h4 
                  className="text-xl font-bold mb-2"
                  itemProp="name"
                >
                  {value.name}
                </h4>
                <p 
                  className="text-gray-600"
                  itemProp="description"
                >
                  {value.description}
                </p>
                <meta itemProp="position" content={`${index + 1}`} />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AboutUs; 