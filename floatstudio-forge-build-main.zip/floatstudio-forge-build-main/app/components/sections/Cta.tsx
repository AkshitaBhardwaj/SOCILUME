"use client";

import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { Calendar } from 'lucide-react';

const Cta = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-900' : 'bg-[#FAFAFA]'} transition-colors duration-300 relative overflow-hidden`}>
      {/* Background decorative elements */}
      {isDark && (
        <>
          <div className="absolute top-0 left-1/3 w-1/3 h-1/3 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none"></div>
          <div className="absolute bottom-0 right-1/3 w-1/3 h-1/3 bg-purple-500/10 blur-[100px] rounded-full pointer-events-none"></div>
        </>
      )}
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className={`rounded-2xl p-12 ${
              isDark 
                ? 'bg-gray-800 border border-gray-700' 
                : 'bg-white shadow-xl'
            }`}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-10">
              <motion.h2 
                className={`text-3xl md:text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                Let's Get Your Business Online — And Growing.
              </motion.h2>
              <motion.p 
                className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                We'll help you start with just $200. And we'll grow it using AI.
              </motion.p>
            </div>
            
            <motion.div 
              className="flex justify-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <a 
                href="https://calendly.com/ankushtagore-socyu/website-consulting" 
                target="_blank" 
                rel="noopener noreferrer"
                className={`inline-flex items-center px-8 py-4 rounded-full font-medium text-lg ${
                  isDark 
                    ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                    : 'bg-[#FFB700] hover:bg-[#FFB700]/90 text-white'
                } transition-colors duration-300`}
              >
                Book My Free Call <Calendar className="ml-2 h-5 w-5" />
              </a>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Cta; 