"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { ChevronDown } from 'lucide-react';
import Script from 'next/script';

const Faqs = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "How long does the website take to build?",
      answer: "Our delivery times vary by package: Starter sites in 3 days, Business sites in 7 days, and Pro sites in 14-30 days depending on complexity. We prioritize both speed and quality to get your business online quickly."
    },
    {
      question: "What if I don't know anything about marketing?",
      answer: "That's exactly why we built SocyU! Our AI marketing tools handle content creation, posting schedules, and campaign management automatically. You don't need any marketing experience - the system does the work for you."
    },
    {
      question: "What is SocyU and how does it work?",
      answer: "SocyU is our proprietary AI marketing platform that automates content creation, influencer matching, and campaign management. It analyzes your website, understands your business, and generates relevant content to post across your social channels. You get lifetime access with any website package."
    },
    {
      question: "Can I get help with Instagram/YouTube too?",
      answer: "Absolutely! We offer Instagram Setup (+$50) and YouTube Channel Branding (+$75) as add-ons to any package. These include profile optimization, content strategy, and initial posts to get you started. SocyU can then help maintain and grow these channels automatically."
    }
  ];

  return (
    <>
      {/* FAQ Schema.org structured data for SEO */}
      <Script
        id="faq-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })
        }}
      />

      <section className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
              Frequently Asked Questions
            </h2>
            <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              Everything you need to know about our services and how we work.
            </p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
              <motion.div 
                key={index}
                className={`mb-4 rounded-xl overflow-hidden ${
                  isDark 
                    ? 'bg-gray-900 border border-gray-800' 
                    : 'bg-white border border-gray-200 shadow-md'
                }`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <button 
                  className={`w-full text-left p-6 flex justify-between items-center ${
                    isDark ? 'text-white' : 'text-[#2C2C54]'
                  } font-medium`}
                  onClick={() => toggleFaq(index)}
                >
                  <span>{faq.question}</span>
                  <motion.div
                    animate={{ rotate: openIndex === index ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ChevronDown className={`h-5 w-5 ${
                      isDark ? 'text-gray-400' : 'text-gray-600'
                    }`} />
                  </motion.div>
                </button>
                
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ 
                    height: openIndex === index ? 'auto' : 0,
                    opacity: openIndex === index ? 1 : 0
                  }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className={`px-6 pb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    {faq.answer}
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>

          {/* SEO Enhancement - Hidden content for search engines */}
          <div className="sr-only">
            <h3>More Questions About Socilume and SocyU</h3>
            <dl>
              <dt>What payment methods do you accept?</dt>
              <dd>We accept all major credit cards, PayPal, and bank transfers. For larger projects, we offer installment plans.</dd>
              
              <dt>Do I own my website after it's built?</dt>
              <dd>Yes, you have full ownership of your website. We provide you with all access credentials upon completion.</dd>
              
              <dt>Is there ongoing support after my website is launched?</dt>
              <dd>Absolutely! We offer technical support for all our clients and ongoing maintenance packages if needed.</dd>
            </dl>
          </div>
        </div>
      </section>
    </>
  );
};

export default Faqs; 