"use client"

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { FloatingCard } from "../ui/floating-card";
import { PremiumCarousel } from "../ui/premium-carousel";
import { cn } from "@/lib/utils";
import { Bot, Users, BarChart3, Sparkles } from 'lucide-react';

const Features = () => {
  const [activeFeature, setActiveFeature] = useState(0);
  const { theme } = useTheme();
  const isDark = theme === "dark";
  
  const features = [
    {
      icon: <Bot className="h-8 w-8" />,
      title: "✍️ Auto-Content Generator",
      description: "Our AI creates daily posts from your site",
      color: isDark ? "bg-indigo-500/20 text-indigo-400" : "bg-[#FFB700]/10 text-[#FFB700]"
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "🤝 Influencer Matching",
      description: "Find real influencers who match your brand",
      color: isDark ? "bg-purple-500/20 text-purple-400" : "bg-[#2C2C54]/10 text-[#2C2C54]"
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "📈 Campaign Management",
      description: "Launch campaigns with one click — no agency needed",
      color: isDark ? "bg-blue-500/20 text-blue-400" : "bg-emerald-500/10 text-emerald-600"
    }
  ];

  // Featured projects for the carousel
  const featuredProjects = [
    {
      title: "SocyU",
      description: "A platform to manage marketing for you.",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
      url: "https://socyu.com"
    },
    {
      title: "RentAra",
      description: "A platform to manage rental properties.",
      image: "https://images.unsplash.com/photo-1505533321630-975218a5f66f",
      url: "https://rentara.in"
    },

  ];

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
            AI Handles Your Socials While You Work on Your Business
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            SocyU's powerful AI tools automate your marketing, so you can focus on what matters most.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className={`p-8 rounded-xl ${isDark ? 'bg-gray-900 border border-gray-800' : 'bg-white shadow-xl'}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
            >
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${feature.color}`}>
                {feature.icon}
              </div>
              <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                {feature.title}
              </h3>
              <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* FREE banner */}
        <motion.div 
          className={`max-w-3xl mx-auto rounded-xl p-8 ${
            isDark 
              ? 'bg-indigo-900/20 border border-indigo-800/50' 
              : 'bg-[#FFB700]/10 border border-[#FFB700]/30'
          } text-center`}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className="flex justify-center mb-4">
            <div className={`px-4 py-2 rounded-full ${
              isDark ? 'bg-indigo-500' : 'bg-[#FFB700]'
            } text-white font-medium text-sm`}>
              FREE with all website packages
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 mb-6">
            <Sparkles className={`h-5 w-5 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />
            <h3 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
              Bonus: Free lifetime access to SocyU — no subscriptions, ever.
            </h3>
          </div>
          <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Unlike other services that charge monthly fees, we give you permanent access to our AI marketing platform. 
            Build your site once, market it forever.
          </p>
        </motion.div>

        {/* Demo section */}
        <motion.div 
          className="mt-20 max-w-4xl mx-auto"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className={`rounded-xl overflow-hidden ${isDark ? 'bg-gray-900 border border-gray-800' : 'bg-white shadow-lg'}`}>
            <div className="p-6">
              <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                See AI in Action
              </h3>
              <div className="bg-black/90 rounded-lg p-4 mb-6">
                <div className="flex items-center mb-4">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                  <div className="mx-auto text-gray-400 text-sm">SocyU AI Dashboard</div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">$</span>
                    <span className="text-gray-300">generate_post --topic="summer sale" --tone="friendly"</span>
                  </div>
                  <div className="pl-6 text-white">
                    <p>Generating content...</p>
                  </div>
                  <div className="pl-6 text-white border-l-2 border-indigo-500 bg-indigo-900/20 p-3 rounded">
                    <p>✨ <span className="text-indigo-300">Summer is heating up and so are our deals!</span> ✨</p>
                    <p className="mt-2">Beat the heat with 20% off all products this weekend only. Use code SUMMER20 at checkout!</p>
                    <p className="mt-2">Tag a friend who needs this in their life! 👇 #SummerSale #WeekendDeals</p>
                  </div>
                </div>
              </div>
              <div className="flex justify-center">
                <a 
                  href="#pricing" 
                  className={`px-6 py-3 rounded-full font-medium ${
                    isDark 
                      ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                      : 'bg-[#FFB700] hover:bg-[#FFB700]/90 text-white'
                  } transition-colors duration-300`}
                >
                  Try SocyU's AI Tools
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;
