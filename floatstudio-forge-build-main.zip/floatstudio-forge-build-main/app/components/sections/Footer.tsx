"use client";

import Link from 'next/link';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import FooterNewsletter from "../ui/FooterNewsletter";
import { Instagram, Youtube, Github, Twitter } from 'lucide-react';

const Footer = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const footerLinks = [
    {
      title: "Navigation",
      links: [
        { name: "Home", href: "/" },
        { name: "Pricing", href: "#pricing" },
        { name: "Blog", href: "/blog" }
      ]
    },
    {
      title: "Support",
      links: [
        { name: "Help Center", href: "/help" },
        { name: "Contact", href: "/contact" },
        { name: "Privacy Policy", href: "/privacy-policy" }
      ]
    },
    {
      title: "Tools",
      links: [
        { name: "SocyU Login", href: "https://app.socyu.com" },
        { name: "Free Instagram Bio Generator", href: "/tools/bio-generator" },
        { name: "Marketing Calculator", href: "/tools/calculator" }
      ]
    }
  ];

  const socialLinks = [
    { name: "Instagram", icon: <Instagram className="h-5 w-5" />, href: "https://instagram.com" },
    { name: "YouTube", icon: <Youtube className="h-5 w-5" />, href: "https://youtube.com" },
    { name: "Twitter", icon: <Twitter className="h-5 w-5" />, href: "https://twitter.com" },
    { name: "GitHub", icon: <Github className="h-5 w-5" />, href: "https://github.com" }
  ];

  return (
    <footer className={`py-16 ${isDark ? 'bg-gray-950 text-gray-300' : 'bg-[#FAFAFA] text-gray-700'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Logo and description */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-block mb-6">
              <h2 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                Soci<span className={isDark ? 'text-indigo-400' : 'text-[#FFB700]'}>Lume</span>
              </h2>
            </Link>
            <p className={`mb-6 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              We build beautiful websites in days and power your marketing with AI. Get started with just $200.
            </p>
            <div className="flex space-x-4 mb-8">
              {socialLinks.map((link, index) => (
                <motion.a
                  key={index}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isDark 
                      ? 'bg-gray-800 hover:bg-gray-700 text-white' 
                      : 'bg-gray-200 hover:bg-gray-300 text-[#2C2C54]'
                  }`}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={link.name}
                >
                  {link.icon}
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((category, index) => (
            <div key={index}>
              <h3 className={`text-lg font-bold mb-4 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                {category.title}
              </h3>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link 
                      href={link.href}
                      className={`hover:${isDark ? 'text-indigo-400' : 'text-[#FFB700]'} transition-colors`}
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter */}
          <div className="lg:col-span-2">
            <FooterNewsletter />
          </div>
        </div>

        {/* Bottom bar */}
        <div className={`mt-16 pt-8 border-t ${isDark ? 'border-gray-800' : 'border-gray-200'}`}>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className={`text-sm ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
              © 2025 Socilume. Built for founders. Powered by AI.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link 
                href="/terms-of-service" 
                className={`text-sm ${isDark ? 'text-gray-500 hover:text-gray-400' : 'text-gray-600 hover:text-gray-800'}`}
              >
                Terms
              </Link>
              <Link 
                href="/privacy-policy" 
                className={`text-sm ${isDark ? 'text-gray-500 hover:text-gray-400' : 'text-gray-600 hover:text-gray-800'}`}
              >
                Privacy
              </Link>
              <Link 
                href="/cookie-policy" 
                className={`text-sm ${isDark ? 'text-gray-500 hover:text-gray-400' : 'text-gray-600 hover:text-gray-800'}`}
              >
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 