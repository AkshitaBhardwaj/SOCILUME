"use client"

import { Button } from "@/src/components/ui/button";
import { motion } from "framer-motion";
import { useTheme } from "next-themes";
import { BrainCircuit, Sparkles } from "lucide-react";

const Hero = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-16">
      {/* Background pattern */}
      <div className="absolute inset-0 z-0">
        <div className={`absolute top-0 left-0 w-full h-full ${
          isDark 
            ? "bg-gradient-to-b from-[#2C2C54] via-gray-900 to-gray-950" 
            : "bg-gradient-to-b from-white via-[#FAFAFA] to-white opacity-70"
        }`}></div>
        
        <motion.div 
          className={`absolute top-1/4 left-1/4 w-56 h-56 rounded-full mix-blend-multiply filter blur-3xl ${
            isDark 
              ? "bg-indigo-900 opacity-20" 
              : "bg-[#FFB700]/20 opacity-30"
          }`}
          animate={{ 
            y: [0, -20, 0],
            opacity: isDark ? [0.15, 0.25, 0.15] : [0.25, 0.35, 0.25]
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity,
            ease: "easeInOut"
          }}
        ></motion.div>
        
        <motion.div 
          className={`absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full mix-blend-multiply filter blur-3xl ${
            isDark 
              ? "bg-purple-900 opacity-20" 
              : "bg-[#FFB700]/10 opacity-30"
          }`}
          animate={{ 
            y: [0, 20, 0],
            opacity: isDark ? [0.15, 0.25, 0.15] : [0.25, 0.35, 0.25]
          }}
          transition={{ 
            duration: 10, 
            repeat: Infinity,
            ease: "easeInOut", 
            delay: 1
          }}
        ></motion.div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 space-y-6 text-center md:text-left">
            <motion.h1 
              className={`text-4xl md:text-5xl lg:text-6xl font-bold ${
                isDark ? "text-white" : "text-[#2C2C54]"
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Your Website. <span className={isDark ? "text-indigo-400" : "text-[#FFB700]"}>Built Fast.</span><br /> 
              <span className="relative inline-block">
                Marketed by AI.
                <motion.span 
                  className={`absolute -bottom-2 left-0 right-0 h-1 ${
                    isDark ? "bg-indigo-400" : "bg-[#FFB700]"
                  } transform`}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.8, delay: 0.6 }}
                ></motion.span>
              </span>
            </motion.h1>
            
            <motion.p 
              className={`text-lg md:text-xl max-w-lg ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              We create your website in days — and grow it with AI. From $200.
            </motion.p>
            
            <motion.div 
              className="flex flex-wrap justify-center md:justify-start gap-4 pt-4"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <motion.a 
                href="/contact" 
                whileHover={{ y: -5 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.2 }}
              >
                <Button className={`${
                  isDark 
                    ? "bg-indigo-500 hover:bg-indigo-600" 
                    : "bg-[#FFB700] hover:bg-[#FFB700]/90"
                } text-white font-medium px-6 py-6 text-lg`}>
                  Get My Website
                </Button>
              </motion.a>
              
              <motion.a 
                href="#pricing" 
                whileHover={{ y: -5 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.2 }}
              >
                <Button 
                  variant="outline" 
                  className={`${
                    isDark 
                      ? "border-gray-700 text-gray-200" 
                      : "border-[#2C2C54]/20 text-[#2C2C54]"
                  } font-medium px-6 py-6 text-lg`}
                >
                  See Plans & Pricing
                </Button>
              </motion.a>
            </motion.div>
          </div>
          
          <div className="w-full md:w-1/2 mt-12 md:mt-0">
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <motion.div 
                className={`absolute -top-6 -left-6 w-24 h-24 rounded-full mix-blend-multiply filter blur-xl ${
                  isDark 
                    ? "bg-indigo-900 opacity-30" 
                    : "bg-[#FFB700]/30 opacity-70"
                }`}
                animate={{ 
                  y: [0, -15, 0],
                }}
                transition={{ 
                  duration: 7, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              ></motion.div>
              
              <motion.div 
                className={`absolute -bottom-8 -right-8 w-40 h-40 rounded-full mix-blend-multiply filter blur-xl ${
                  isDark 
                    ? "bg-purple-900 opacity-30" 
                    : "bg-[#FFB700]/20 opacity-60"
                }`}
                animate={{ 
                  y: [0, 15, 0],
                }}
                transition={{ 
                  duration: 8, 
                  repeat: Infinity,
                  ease: "easeInOut", 
                  delay: 1
                }}
              ></motion.div>
              
              <motion.div 
                className={`relative z-10 ${
                  isDark 
                    ? "bg-gray-800 shadow-xl" 
                    : "bg-white shadow-2xl"
                } rounded-2xl overflow-hidden`}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.4 }}
              >
                {/* AI building a website animation/image */}
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158" 
                    alt="AI building a website" 
                    className="w-full h-auto object-cover rounded-t-2xl"
                  />
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-black/50 to-transparent flex items-end">
                    <div className="p-4 text-white">
                      <div className="flex items-center space-x-2 mb-2">
                        <BrainCircuit className="h-5 w-5 text-[#FFB700]" />
                        <span className="font-medium">AI Content Generator</span>
                      </div>
                      <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-[#FFB700]"
                          initial={{ width: "0%" }}
                          animate={{ width: "75%" }}
                          transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className={`p-6 ${isDark ? "bg-gray-800" : "bg-white"}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className={`font-bold ${
                        isDark ? "text-white" : "text-[#2C2C54]"
                      }`}>Dashboard Preview</h3>
                      <p className={`text-sm ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}>AI Marketing Automation</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Sparkles className="h-4 w-4 text-[#FFB700]" />
                      <span className={`text-sm font-medium ${isDark ? "text-white" : "text-[#2C2C54]"}`}>
                        SocyU Powered
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero; 