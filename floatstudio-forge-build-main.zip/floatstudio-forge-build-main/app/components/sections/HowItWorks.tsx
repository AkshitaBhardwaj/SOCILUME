"use client"

import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { PhoneCall, Code, TrendingUp } from 'lucide-react';

const HowItWorks = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const steps = [
    {
      icon: <PhoneCall className={`h-8 w-8 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />,
      title: "Book a Call",
      description: "We understand your business in 15 minutes or less."
    },
    {
      icon: <Code className={`h-8 w-8 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />,
      title: "We Build Your Site",
      description: "Professional. Fast. Mobile-ready. SEO-friendly."
    },
    {
      icon: <TrendingUp className={`h-8 w-8 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />,
      title: "Your Growth Begins",
      description: "SocyU's AI runs your marketing. You sit back."
    }
  ];

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-900' : 'bg-[#FAFAFA]'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
            3 Simple Steps to Grow Your Brand
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Our streamlined process gets your business online and growing with minimal effort on your part.
          </p>
        </motion.div>

        <div className="relative max-w-5xl mx-auto">
          {/* Progress Line */}
          <div className={`absolute top-24 left-0 right-0 h-1 ${isDark ? 'bg-gray-800' : 'bg-gray-200'} hidden md:block`}>
            <motion.div 
              className={`h-full ${isDark ? 'bg-indigo-500' : 'bg-[#FFB700]'}`}
              initial={{ width: "0%" }}
              whileInView={{ width: "100%" }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              viewport={{ once: true }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                className="flex flex-col items-center text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <motion.div 
                  className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${
                    isDark ? 'bg-gray-800' : 'bg-white'
                  } shadow-lg`}
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.2 }}
                >
                  {step.icon}
                </motion.div>
                
                <motion.div 
                  className={`w-8 h-8 rounded-full flex items-center justify-center mb-4 ${
                    isDark ? 'bg-indigo-500' : 'bg-[#FFB700]'
                  } text-white font-bold`}
                >
                  {index + 1}
                </motion.div>
                
                <h3 className={`text-xl font-bold mb-3 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                  {step.title}
                </h3>
                
                <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Visual Illustration */}
        <motion.div 
          className="mt-20 max-w-4xl mx-auto"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className={`rounded-xl overflow-hidden ${isDark ? 'bg-gray-800' : 'bg-white shadow-lg'}`}>
            <div className="p-6">
              <div className="flex flex-col md:flex-row gap-4 items-center">
                <div className="md:w-1/2">
                  <img 
                    src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070" 
                    alt="Dashboard showing growth" 
                    className="rounded-lg shadow-md"
                  />
                </div>
                <div className="md:w-1/2 space-y-4">
                  <h3 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                    Watch Your Business Transform
                  </h3>
                  <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    After we build your site, SocyU's AI marketing tools take over to generate content, 
                    find influencers, and manage your campaigns automatically.
                  </p>
                  <div className={`flex items-center ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`}>
                    <a href="#pricing" className="flex items-center font-medium">
                      Get started today 
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks; 