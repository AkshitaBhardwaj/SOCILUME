"use client";

import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import Link from 'next/link';

const LegalContent = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const legalPages = [
    {
      title: "Terms of Service",
      description: "The agreement governing your use of our website and services.",
      path: "/terms-of-service",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      ),
    },
    {
      title: "Privacy Policy",
      description: "How we collect, use, and protect your personal information.",
      path: "/privacy-policy",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      ),
    },
    {
      title: "Cookie Policy",
      description: "Details about how we use cookies and similar technologies on our website.",
      path: "/cookie-policy",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      ),
    },
    {
      title: "Sitemap",
      description: "An overview of all pages available on our website.",
      path: "/sitemap",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
        </svg>
      ),
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <h1 className={`text-3xl md:text-4xl font-bold mb-8 text-center ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Legal <span className={isDark ? "text-indigo-400" : "text-amber-500"}>Information</span>
          </h1>
          
          <p className={`text-lg text-center mb-16 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            On this page, you can find all of our legal documents and policies. We value transparency and 
            want to make it easy for you to understand how we handle your data and what to expect when using our services.
          </p>
          
          <motion.div 
            className="grid gap-8 md:grid-cols-2"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {legalPages.map((page) => (
              <motion.div 
                key={page.path}
                variants={itemVariants}
              >
                <Link href={page.path}>
                  <div className={`p-8 rounded-xl h-full flex flex-col transition-all duration-300 ${
                    isDark 
                      ? 'bg-gray-900 border border-gray-800 hover:border-indigo-500/30' 
                      : 'bg-white shadow-lg hover:shadow-xl'
                  }`}>
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${
                      isDark 
                        ? 'bg-indigo-500/20 text-indigo-400' 
                        : 'bg-amber-100 text-amber-600'
                    }`}>
                      {page.icon}
                    </div>
                    
                    <h2 className={`text-xl font-bold mb-3 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {page.title}
                    </h2>
                    
                    <p className={`mb-6 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                      {page.description}
                    </p>
                    
                    <div className="mt-auto">
                      <span className={`inline-flex items-center font-medium ${
                        isDark 
                          ? 'text-indigo-400 hover:text-indigo-300' 
                          : 'text-amber-600 hover:text-amber-700'
                      }`}>
                        Read more
                        <svg className="w-5 h-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
          
          <div className={`mt-16 p-8 rounded-xl text-center bg-opacity-50 border border-dashed backdrop-blur-sm
            ${isDark ? 'bg-indigo-900/5 border-indigo-500/20' : 'bg-amber-50 border-amber-200'}`}>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Need Help Understanding Our Policies?
            </h3>
            <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              If you have any questions about our terms of service, privacy practices, or other legal matters, 
              our team is happy to assist you.
            </p>
            <Link href="/contact">
              <motion.button 
                className={`px-6 py-3 rounded-full font-medium ${
                  isDark 
                    ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                    : 'bg-amber-500 hover:bg-amber-600 text-white'
                } transition-colors duration-300`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Contact Our Team
              </motion.button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default LegalContent; 