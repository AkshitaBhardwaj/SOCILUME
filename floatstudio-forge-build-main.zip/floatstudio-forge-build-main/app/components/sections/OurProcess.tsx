"use client";

import { motion } from "framer-motion";
import { useTheme } from "next-themes";

const OurProcess = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const processSteps = [
    {
      id: 1,
      title: "Discovery",
      description: "We start by understanding your business, goals, target audience, and unique challenges to ensure perfect alignment with your vision.",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      )
    },
    {
      id: 2,
      title: "Strategy",
      description: "Our team crafts a comprehensive roadmap, including site architecture, user flow, and technical specifications tailored to your requirements.",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )
    },
    {
      id: 3,
      title: "Design",
      description: "Our designers create stunning, user-centric mockups with premium animations and interactive elements that elevate your brand.",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
        </svg>
      )
    },
    {
      id: 4,
      title: "Development",
      description: "Our engineering team brings designs to life with clean, optimized code that ensures your site is fast, responsive, and future-proof.",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
        </svg>
      )
    },
    {
      id: 5,
      title: "Testing",
      description: "We rigorously test across devices and browsers to ensure flawless functionality, optimal performance, and accessibility compliance.",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      )
    },
    {
      id: 6,
      title: "Launch & Support",
      description: "We handle deployment and provide comprehensive training and ongoing support to ensure your digital asset continues to thrive.",
      icon: (
        <svg className="w-8 h-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
        </svg>
      )
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  return (
    <section 
      id="our-process-section" 
      className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300 relative overflow-hidden`}
    >
      {/* Background decorative elements */}
      {isDark && (
        <>
          <div className="absolute top-20 left-20 w-64 h-64 bg-indigo-900/10 rounded-full blur-[100px] animate-pulse-glow"></div>
          <div className="absolute bottom-20 right-20 w-64 h-64 bg-purple-900/10 rounded-full blur-[100px] animate-pulse-glow"></div>
        </>
      )}

      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 
            id="our-process-heading"
            className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}
          >
            Our <span className={isDark ? "text-indigo-400" : "text-amber-500"}>Blueprint</span> for Success:
            A Streamlined Development Journey
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            We follow a systematic approach to transform your vision into a stunning digital reality.
            Each step is designed to deliver maximum value and ensure exceptional results.
          </p>
        </motion.div>

        {/* Process steps timeline */}
        <motion.div 
          className="relative max-w-5xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {/* Timeline line */}
          <div className={`absolute left-1/2 transform -translate-x-1/2 w-1 h-full ${isDark ? 'bg-gray-800' : 'bg-gray-200'} hidden md:block`}></div>
          
          {processSteps.map((step, index) => (
            <motion.div 
              key={step.id}
              className={`flex flex-col md:flex-row items-center mb-12 md:mb-24 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
              variants={itemVariants}
            >
              {/* Number indicator */}
              <div className="relative">
                <motion.div 
                  className={`w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold z-10 ${
                    isDark 
                      ? 'bg-indigo-500 text-white' 
                      : 'bg-amber-500 text-white'
                  }`}
                  whileHover={{ scale: 1.1 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  {step.id}
                </motion.div>
                <div className={`hidden md:block absolute top-1/2 ${
                  index % 2 === 0 ? 'right-full' : 'left-full'
                } transform -translate-y-1/2 w-12 h-1 ${
                  isDark 
                    ? 'bg-indigo-500/60' 
                    : 'bg-amber-500/60'
                }`}></div>
              </div>

              {/* Content */}
              <div className={`md:w-5/12 ${
                index % 2 === 0 ? 'md:mr-auto md:pl-12' : 'md:ml-auto md:pr-12'
              } mt-6 md:mt-0`}>
                <div className={`p-6 rounded-xl ${
                  isDark 
                    ? 'bg-gray-900 border border-gray-800' 
                    : 'bg-white shadow-lg'
                }`}>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
                    isDark 
                      ? 'bg-gray-800 text-indigo-400' 
                      : 'bg-amber-100 text-amber-600'
                  }`}>
                    {step.icon}
                  </div>
                  <h3 className={`text-xl font-bold mb-2 ${
                    isDark ? 'text-white' : 'text-gray-900'
                  }`}>
                    {step.title}
                  </h3>
                  <p className={`${
                    isDark ? 'text-gray-300' : 'text-gray-600'
                  }`}>
                    {step.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <a href="/contact">
            <motion.button 
              className={`px-8 py-3 rounded-full font-medium ${
                isDark 
                  ? 'bg-indigo-500 hover:bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                  : 'bg-amber-500 hover:bg-amber-600 text-white shadow-lg'
              } transition-all`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              Start Your Project
            </motion.button>
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default OurProcess; 