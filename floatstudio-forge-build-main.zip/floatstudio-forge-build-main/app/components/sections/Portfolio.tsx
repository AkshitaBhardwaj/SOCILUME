"use client";

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { EnhancedCard } from "../ui/enhanced-card";
import { useTheme } from "next-themes";
import Link from 'next/link';

interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string;
  technologies: string[];
  link: string;
}

const Portfolio = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const categories = [
    { id: "all", name: "All Projects" },
    { id: "website", name: "Websites" },
    { id: "ecommerce", name: "E-commerce" },
    { id: "webapp", name: "Web Apps" },
    { id: "design", name: "UI/UX Design" },
  ];

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        // In a real implementation, this would be an actual API call:
        // const response = await fetch('https://api.socyu.com/api/projects');
        // const data = await response.json();
        
        // For demonstration purposes, using mock data:
        const mockData: Project[] = [
          {
            id: "1",
            title: "SocyU AI Platform",
            description: "A platform to manage marketing for you.",
            image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070",
            category: "webapp",
            technologies: ["Next.js", "TypeScript", "TailwindCSS", "MongoDB"],
            link: "https://socyu.com",
            featured: true
          },
          {
            id: "2",
            title: "RentAra Property Management",
            description: "A comprehensive rental management tool that streamlines property management, rent collection, and tenant communications.",
            image: "https://images.unsplash.com/photo-1560185127-6ed189bf02f4?q=80&w=2070",
            category: "webapp",
            technologies: ["React", "Node.js", "Express", "MongoDB"],
            link: "https://www.rentara.in",
            featured: true
          },
          {
            id: "7",
            title: "PressPlay Music & Audio",
            description: "A sleek music streaming platform offering curated playlists, personalized audio content, and an intuitive mobile-first experience.",
            image: "https://images.unsplash.com/photo-1511376777868-611b54f68947?q=80&w=2070",
            category: "webapp",
            technologies: ["React", "Redux", "Node.js", "AWS", "Firebase"],
            link: "https://pressplay.me/",
            featured: false
          },
          {
            id: "8",
            title: "Mr.Bet Gaming Platform",
            description: "A vibrant and secure online gaming and casino platform with real-time multiplayer capabilities and rich UI/UX design for seamless entertainment.",
            image: "https://images.unsplash.com/photo-1549924231-f129b911e442?q=80&w=2070",
            category: "webapp",
            technologies: ["Vue.js", "Socket.IO", "Express", "MongoDB", "Stripe"],
            link: "https://mr.bet/in",
            featured: false
          },
          {
            id: "4",
            title: "Focus Fuel Flow",
            description: "A productivity tool designed to enhance focus and efficiency through structured workflows and task management.",
            image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=2070",
            category: "webapp",
            technologies: ["Vue.js", "Firebase", "TailwindCSS"],
            link: "https://preview--focus-fuel-flow.lovable.app/",
            featured: false
          },
          {
            id: "6",
            title: "Content Sharer Hub",
            description: "A centralized platform for content creators to share, manage, and collaborate on various media projects.",
            image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2070",
            category: "webapp",
            technologies: ["Next.js", "TypeScript", "TailwindCSS", "Firebase"],
            link: "https://preview--content-sharer-hub.lovable.app/",
            featured: false
          }
        ];
        
        setProjects(mockData);
        setIsLoading(false);
      } catch (err) {
        setError("Failed to load projects. Please try again later.");
        setIsLoading(false);
      }
    };

    fetchProjects();
  }, []);

  const filteredProjects = activeCategory === "all" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  return (
    <section id="portfolio-section" className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-gray-50'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 
            id="portfolio-heading" 
            className={`text-3xl md:text-4xl font-bold mb-6 ${
              isDark ? 'text-white' : 'text-gray-900'
            }`}
          >
            Our Signature Work: <span className={isDark ? "text-indigo-400" : "text-amber-500"}>
              Transforming Visions
            </span> into Digital Reality
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Browse our curated collection of premium projects that showcase our expertise in creating 
            stunning, high-performance digital experiences across various industries.
          </p>
        </motion.div>

        {/* Category filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <motion.button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === category.id
                  ? isDark 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                    : 'bg-amber-500 text-white shadow-md'
                  : isDark 
                    ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.2 }}
            >
              {category.name}
            </motion.button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <div className={`w-10 h-10 border-4 border-t-transparent rounded-full animate-spin ${
              isDark ? 'border-indigo-400' : 'border-amber-500'
            }`}></div>
          </div>
        ) : error ? (
          <div className={`text-center py-20 ${isDark ? 'text-red-400' : 'text-red-600'}`}>
            {error}
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            {filteredProjects.map((project, index) => (
              <motion.div key={project.id} variants={itemVariants}>
                <Link href={project.link} target="_blank" rel="noopener noreferrer">
                  <EnhancedCard className={`h-full card-hover ${isDark ? 'hover:border-indigo-500/30' : 'hover:border-amber-500/30'}`} delay={index * 0.1}>
                    <div className="relative aspect-[16/9] mb-4 overflow-hidden rounded-lg">
                      <img 
                        src={project.image} 
                        alt={project.title} 
                        className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                      />
                    </div>
                    <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {project.title}
                    </h3>
                    <p className={`text-sm mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech) => (
                        <span 
                          key={tech} 
                          className={`text-xs px-2 py-1 rounded-full ${
                            isDark 
                              ? 'bg-gray-800 text-gray-300' 
                              : 'bg-gray-200 text-gray-700'
                          }`}
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-medium uppercase ${
                        isDark 
                          ? 'text-indigo-400' 
                          : 'text-amber-600'
                      }`}>
                        {categories.find(c => c.id === project.category)?.name || project.category}
                      </span>
                      <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>View Project →</span>
                    </div>
                  </EnhancedCard>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default Portfolio; 