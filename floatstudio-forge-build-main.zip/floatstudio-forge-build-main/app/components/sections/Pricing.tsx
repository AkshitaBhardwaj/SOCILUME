"use client";

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { Check, Calendar, ArrowRight } from 'lucide-react';
import { Button } from "@/src/components/ui/button";

const Pricing = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);

  const toggleAddOn = (addOn: string) => {
    if (selectedAddOns.includes(addOn)) {
      setSelectedAddOns(selectedAddOns.filter(item => item !== addOn));
    } else {
      setSelectedAddOns([...selectedAddOns, addOn]);
    }
  };

  const plans = [
    {
      name: "Starter",
      description: "1-Page Landing Website + SocyU access",
      price: "$200",
      deliveryTime: "3 Days",
      features: [
        "Professional landing page",
        "Mobile responsive design",
        "Basic SEO setup",
        "Contact form integration",
        "SocyU AI marketing access"
      ],
      popular: false
    },
    {
      name: "Business",
      description: "Full Website (5-7 pages) + Social Setup",
      price: "$500",
      deliveryTime: "7 Days",
      features: [
        "5-7 page professional website",
        "Mobile responsive design",
        "Complete SEO setup",
        "Social media integration",
        "Contact forms & lead capture",
        "Google Analytics setup",
        "SocyU AI marketing access"
      ],
      popular: true
    },
    {
      name: "Pro",
      description: "Enterprise-level Site + Branding + SEO",
      price: "$900+",
      deliveryTime: "14-30 Days",
      features: [
        "10+ page custom website",
        "Custom branding package",
        "Advanced SEO optimization",
        "E-commerce functionality",
        "Custom animations & interactions",
        "Premium integrations",
        "SocyU AI marketing access",
        "Priority support"
      ],
      popular: false
    }
  ];

  const addOns = [
    {
      name: "Instagram Setup",
      price: "$50",
      id: "instagram"
    },
    {
      name: "YouTube Channel Branding",
      price: "$75",
      id: "youtube"
    },
    {
      name: "SEO Optimization",
      price: "$100",
      id: "seo"
    }
  ];

  return (
    <section id="pricing" className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
            Transparent Pricing That Grows With You
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Simple, honest pricing with no hidden fees. Choose the plan that fits your business needs.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              className={`rounded-xl overflow-hidden ${
                isDark 
                  ? 'bg-gray-900 border border-gray-800' 
                  : 'bg-white border border-gray-100 shadow-xl'
              } ${
                plan.popular 
                  ? 'relative transform md:-translate-y-4 md:scale-105' 
                  : ''
              }`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
            >
              {plan.popular && (
                <div className={`absolute top-0 right-0 bg-[#FFB700] text-white px-4 py-1 text-sm font-medium`}>
                  Most Popular
                </div>
              )}
              
              <div className="p-8">
                <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                  {plan.name}
                </h3>
                <p className={`mb-6 text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                  {plan.description}
                </p>
                
                <div className="mb-6">
                  <span className={`text-4xl font-bold ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                    {plan.price}
                  </span>
                </div>
                
                <div className={`flex items-center mb-8 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  <Calendar className="h-5 w-5 mr-2" />
                  <span>Delivery Time: {plan.deliveryTime}</span>
                </div>
                
                <div className="mb-8">
                  <h4 className={`text-sm font-medium mb-4 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                    What's included:
                  </h4>
                  <ul className="space-y-3">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <Check className={`h-5 w-5 mr-2 flex-shrink-0 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />
                        <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <Button 
                  className={`w-full py-6 ${
                    plan.popular 
                      ? isDark 
                        ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                        : 'bg-[#FFB700] hover:bg-[#FFB700]/90 text-white'
                      : isDark 
                        ? 'bg-gray-800 hover:bg-gray-700 text-white' 
                        : 'bg-gray-100 hover:bg-gray-200 text-[#2C2C54]'
                  }`}
                >
                  Get Started
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Optional Add-ons */}
        <motion.div 
          className={`max-w-3xl mx-auto rounded-xl p-8 ${
            isDark ? 'bg-gray-900 border border-gray-800' : 'bg-gray-50'
          }`}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
            Optional Add-ons
          </h3>
          
          <div className="space-y-4">
            {addOns.map((addon, index) => (
              <div 
                key={index} 
                className={`flex items-center justify-between p-4 rounded-lg cursor-pointer ${
                  selectedAddOns.includes(addon.id)
                    ? isDark 
                      ? 'bg-indigo-900/30 border border-indigo-800' 
                      : 'bg-[#FFB700]/10 border border-[#FFB700]/30'
                    : isDark 
                      ? 'bg-gray-800 border border-gray-700' 
                      : 'bg-white border border-gray-200'
                }`}
                onClick={() => toggleAddOn(addon.id)}
              >
                <div className="flex items-center">
                  <div className={`w-5 h-5 rounded-full mr-3 flex items-center justify-center ${
                    selectedAddOns.includes(addon.id)
                      ? isDark ? 'bg-indigo-500' : 'bg-[#FFB700]'
                      : isDark ? 'bg-gray-700' : 'bg-gray-200'
                  }`}>
                    {selectedAddOns.includes(addon.id) && (
                      <Check className="h-3 w-3 text-white" />
                    )}
                  </div>
                  <span className={`font-medium ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                    {addon.name}
                  </span>
                </div>
                <span className={`${isDark ? 'text-indigo-400' : 'text-[#FFB700]'} font-bold`}>
                  +{addon.price}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <div className="text-center mt-16">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            viewport={{ once: true }}
          >
            <a 
              href="https://calendly.com/ankushtagore-socyu/website-consulting" 
              target="_blank" 
              rel="noopener noreferrer"
              className={`inline-flex items-center px-8 py-4 rounded-full font-medium ${
                isDark 
                  ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                  : 'bg-[#FFB700] hover:bg-[#FFB700]/90 text-white'
              } transition-colors duration-300`}
            >
              Book a Free Call <Calendar className="ml-2 h-5 w-5" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Pricing; 