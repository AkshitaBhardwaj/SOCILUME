"use client";

import { motion } from 'framer-motion';
import { useTheme } from "next-themes";

const PrivacyPolicyContent = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <h1 className={`text-3xl md:text-4xl font-bold mb-8 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Privacy <span className={isDark ? "text-indigo-400" : "text-amber-500"}>Policy</span>
          </h1>
          
          <div className={`prose max-w-none ${isDark ? 'prose-invert' : ''}`}>
            <p className="lead">Last Updated: May 15, 2023</p>
            
            <p>
              At SociLume, we respect your privacy and are committed to protecting your personal data. 
              This Privacy Policy explains how we collect, use, disclose, and safeguard your information when 
              you visit our website or engage with our services.
            </p>

            <h2>Information We Collect</h2>
            
            <p>We may collect personal information that you voluntarily provide to us when:</p>
            
            <ul>
              <li>Filling out forms on our website</li>
              <li>Subscribing to our newsletter</li>
              <li>Requesting information about our services</li>
              <li>Contacting us through email or phone</li>
              <li>Participating in surveys or promotions</li>
            </ul>
            
            <p>The personal information we collect may include:</p>
            
            <ul>
              <li>Name, email address, phone number, and company name</li>
              <li>Contact preferences and areas of interest</li>
              <li>Information about your project requirements</li>
              <li>Other details you choose to provide</li>
            </ul>
            
            <h2>Automatically Collected Information</h2>
            
            <p>
              When you visit our website, our servers may automatically log standard data provided by your web browser, including:
            </p>
            
            <ul>
              <li>IP address</li>
              <li>Browser type and version</li>
              <li>Pages you visit and time spent on those pages</li>
              <li>Time and date of your visit</li>
              <li>Referring website addresses</li>
            </ul>
            
            <p>
              We also use cookies and similar tracking technologies to enhance your experience on our website. 
              You can manage your cookie preferences through your browser settings.
            </p>
            
            <h2>How We Use Your Information</h2>
            
            <p>We may use the information we collect to:</p>
            
            <ul>
              <li>Provide, operate, and maintain our website and services</li>
              <li>Respond to your inquiries and fulfill your requests</li>
              <li>Send administrative information, such as updates, security alerts, and support messages</li>
              <li>Process transactions and send related information</li>
              <li>Send marketing communications, if you have opted in to receive them</li>
              <li>Personalize your experience on our website</li>
              <li>Conduct analysis to improve our website and services</li>
              <li>Protect against fraudulent, unauthorized, or illegal activity</li>
            </ul>
            
            <h2>Disclosure of Your Information</h2>
            
            <p>We may share your personal information with:</p>
            
            <ul>
              <li>Service providers who perform services on our behalf</li>
              <li>Professional advisors, such as lawyers, auditors, and insurers</li>
              <li>Regulatory authorities, law enforcement, or government agencies when required by law</li>
              <li>A buyer or successor in the event of a merger, acquisition, or similar business transaction</li>
            </ul>
            
            <p>
              We do not sell, rent, or trade your personal information with third parties for their marketing purposes.
            </p>
            
            <h2>Data Security</h2>
            
            <p>
              We implement appropriate technical and organizational measures to protect your personal information 
              against unauthorized access, disclosure, alteration, or destruction. However, no method of transmission 
              over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
            </p>
            
            <h2>Your Rights</h2>
            
            <p>Depending on your location, you may have certain rights regarding your personal information, including:</p>
            
            <ul>
              <li>Right to access the personal information we hold about you</li>
              <li>Right to rectify any inaccurate or incomplete information</li>
              <li>Right to erase your personal information</li>
              <li>Right to restrict or object to processing of your personal information</li>
              <li>Right to data portability</li>
              <li>Right to withdraw consent at any time</li>
            </ul>
            
            <p>
              To exercise any of these rights, please contact us using the information provided in the "Contact Us" section.
            </p>
            
            <h2>Children's Privacy</h2>
            
            <p>
              Our website is not intended for children under 16 years of age. We do not knowingly collect personal 
              information from children under 16. If you are a parent or guardian and believe your child has provided 
              us with personal information, please contact us.
            </p>
            
            <h2>Third-Party Links</h2>
            
            <p>
              Our website may contain links to third-party websites. We have no control over and assume no responsibility 
              for the content, privacy policies, or practices of any third-party websites or services.
            </p>
            
            <h2>Changes to This Privacy Policy</h2>
            
            <p>
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new 
              Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy 
              Policy periodically for any changes.
            </p>
            
            <h2>Contact Us</h2>
            
            <p>
              If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:
            </p>
            
            <p>
              SociLume<br />
              12A, Princess Street<br />
              Marine Lines, Mumbai-400002<br />
              Email: privacy@SociLume.com<br />
              Phone: +91 8171556685
            </p>
          </div>
          
          <div className="mt-12 text-center">
            <a
              href="/contact"
              className={`inline-flex items-center px-6 py-3 rounded-full font-medium ${
                isDark 
                  ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                  : 'bg-amber-500 hover:bg-amber-600 text-white'
              } transition-colors duration-300`}
            >
              Questions? Contact Us
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default PrivacyPolicyContent; 