import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import Script from "next/script";

// Icons
import { Code, Paintbrush, ShoppingBag, Search, Settings, Headphones } from "lucide-react";

const Services = () => {
  // SEO-optimized data
  const servicesData = {
    title: "Our Expertise: Comprehensive Web Development Solutions",
    intro: "We offer a full spectrum of web development services designed to elevate your brand and optimize your online performance. From initial concept to final deployment and beyond, we are your trusted digital partner.",
    serviceItems: [
      {
        name: "Custom Next.js Development",
        description: "Building blazing-fast, scalable, and SEO-friendly websites and web applications using the power of Next.js.",
        icon: <Code className="h-8 w-8 text-blue-600" />,
        slug: "next-js-development"
      },
      {
        name: "UI/UX Design Excellence",
        description: "Creating intuitive, engaging, and aesthetically stunning user interfaces that provide an exceptional user experience and drive conversions.",
        icon: <Paintbrush className="h-8 w-8 text-blue-600" />,
        slug: "ui-ux-design"
      },
      {
        name: "E-commerce Solutions",
        description: "Developing robust and secure e-commerce platforms with seamless payment integrations and optimized shopping experiences.",
        icon: <ShoppingBag className="h-8 w-8 text-blue-600" />,
        slug: "ecommerce-solutions"
      },
      {
        name: "SEO & Performance Optimization",
        description: "Implementing advanced SEO strategies and performance tuning to ensure your website ranks high and loads instantly.",
        icon: <Search className="h-8 w-8 text-blue-600" />,
        slug: "seo-optimization"
      },
      {
        name: "Content Management Systems (CMS)",
        description: "Integrating powerful and flexible CMS solutions for easy content updates and management.",
        icon: <Settings className="h-8 w-8 text-blue-600" />,
        slug: "cms-integration"
      },
      {
        name: "Website Maintenance & Support",
        description: "Providing ongoing support, security updates, and maintenance to keep your website running smoothly and efficiently.",
        icon: <Headphones className="h-8 w-8 text-blue-600" />,
        slug: "website-maintenance"
      }
    ]
  };

  return (
    <>
      {/* Services Schema.org markup for advanced SEO */}
      <Script
        id="services-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ItemList",
            "itemListElement": servicesData.serviceItems.map((service, index) => ({
              "@type": "ListItem",
              "position": index + 1,
              "item": {
                "@type": "Service",
                "name": service.name,
                "description": service.description,
                "url": `https://example.com/services/${service.slug}`,
                "provider": {
                  "@type": "ProfessionalService",
                  "name": "SociLume",
                  "url": "https://example.com"
                }
              }
            }))
          })
        }}
      />

      <div 
        className="bg-gray-50 py-24" 
        id="services-section"
      >
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 
              id="services-heading"
              className="text-4xl font-bold mb-6"
              itemProp="name"
            >
              {servicesData.title}
            </h2>
            <p 
              className="text-xl text-gray-600 leading-relaxed"
              itemProp="description"
            >
              {servicesData.intro}
            </p>
          </div>

          <div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            itemScope
            itemType="https://schema.org/ItemList"
          >
            {servicesData.serviceItems.map((service, index) => (
              <Card 
                key={index}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
                itemProp="itemListElement"
                itemScope
                itemType="https://schema.org/Service"
              >
                <CardContent className="p-8">
                  <div className="mb-6">
                    {service.icon}
                  </div>
                  <h3 
                    className="text-2xl font-bold mb-4"
                    itemProp="name"
                  >
                    {service.name}
                  </h3>
                  <p 
                    className="text-gray-600"
                    itemProp="description"
                  >
                    {service.description}
                  </p>
                  <meta itemProp="url" content={`https://example.com/services/${service.slug}`} />
                  <meta itemProp="provider" content="SociLume" />
                  <meta itemProp="position" content={`${index + 1}`} />
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-16 text-center">
            <a 
              href="/services" 
              className="inline-flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-300"
              aria-label="Explore our comprehensive web development services in detail"
              rel="nofollow"
            >
              Explore All Services
              <svg className="ml-2 h-5 w-5" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                <path d="M9 5l7 7-7 7"></path>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Services; 