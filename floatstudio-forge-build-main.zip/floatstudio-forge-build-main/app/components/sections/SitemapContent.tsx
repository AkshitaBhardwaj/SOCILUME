"use client";

import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import Link from 'next/link';

interface SitemapCategory {
  title: string;
  links: Array<{
    title: string;
    path: string;
    description?: string;
  }>;
}

const SitemapContent = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const sitemapData: SitemapCategory[] = [
    {
      title: "Main Pages",
      links: [
        { 
          title: "Home", 
          path: "/", 
          description: "Our homepage showcasing our services and expertise"
        },
        { 
          title: "About", 
          path: "/about", 
          description: "Learn about our company, mission, and team"
        },
        { 
          title: "Services", 
          path: "/services", 
          description: "Explore our range of web design and development services"
        },
        { 
          title: "Portfolio", 
          path: "/portfolio", 
          description: "View our showcase of client projects and case studies"
        },
        { 
          title: "Contact", 
          path: "/contact", 
          description: "Get in touch with our team"
        }
      ]
    },
    {
      title: "Legal Information",
      links: [
        { 
          title: "Legal Hub", 
          path: "/legal", 
          description: "Overview of all legal documents and policies"
        },
        { 
          title: "Terms of Service", 
          path: "/terms-of-service", 
          description: "Our terms and conditions for using our services"
        },
        { 
          title: "Privacy Policy", 
          path: "/privacy-policy", 
          description: "How we collect and handle your personal data"
        },
        { 
          title: "Cookie Policy", 
          path: "/cookie-policy", 
          description: "Our policy regarding cookies and similar technologies"
        }
      ]
    },
    {
      title: "Services",
      links: [
        { 
          title: "Web Design", 
          path: "/services/web-design" 
        },
        { 
          title: "Web Development", 
          path: "/services/web-development" 
        },
        { 
          title: "E-commerce", 
          path: "/services/ecommerce" 
        },
        { 
          title: "UI/UX Design", 
          path: "/services/ui-ux-design" 
        },
        { 
          title: "Mobile Apps", 
          path: "/services/mobile-apps" 
        },
        { 
          title: "Digital Marketing", 
          path: "/services/digital-marketing" 
        }
      ]
    },
    {
      title: "Resources",
      links: [
        { 
          title: "Blog", 
          path: "/blog" 
        },
        { 
          title: "Case Studies", 
          path: "/case-studies" 
        },
        { 
          title: "FAQ", 
          path: "/faq" 
        },
        { 
          title: "Resources Hub", 
          path: "/resources" 
        }
      ]
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-5xl mx-auto"
        >
          <h1 className={`text-3xl md:text-4xl font-bold mb-8 text-center ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Site<span className={isDark ? "text-indigo-400" : "text-amber-500"}>map</span>
          </h1>
          
          <p className={`text-lg text-center mb-16 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Find your way around our website with this comprehensive sitemap. 
            Below you'll find links to all pages organized by category.
          </p>
          
          <motion.div 
            className="grid gap-x-12 gap-y-16 md:grid-cols-2"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {sitemapData.map((category, index) => (
              <motion.div 
                key={index}
                variants={itemVariants}
                className="mb-8"
              >
                <h2 className={`text-xl font-bold mb-6 pb-2 border-b ${
                  isDark 
                    ? 'text-white border-gray-800' 
                    : 'text-gray-900 border-gray-200'
                }`}>
                  {category.title}
                </h2>
                
                <ul className="space-y-4">
                  {category.links.map((link, linkIndex) => (
                    <motion.li 
                      key={linkIndex}
                      variants={itemVariants}
                    >
                      <Link 
                        href={link.path}
                        className={`group block ${
                          isDark ? 'hover:bg-gray-900' : 'hover:bg-gray-50'
                        } p-3 rounded-lg transition-colors duration-300`}
                      >
                        <span className={`font-medium block ${
                          isDark 
                            ? 'text-indigo-400 group-hover:text-indigo-300' 
                            : 'text-amber-600 group-hover:text-amber-700'
                        }`}>
                          {link.title}
                        </span>
                        
                        {link.description && (
                          <span className={`text-sm block mt-1 ${
                            isDark ? 'text-gray-400' : 'text-gray-600'
                          }`}>
                            {link.description}
                          </span>
                        )}
                      </Link>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>
          
          <div className={`mt-16 p-8 rounded-xl text-center ${
            isDark ? 'bg-gray-900 border border-gray-800' : 'bg-gray-50'
          }`}>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Can't Find What You're Looking For?
            </h3>
            <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              If you're having trouble finding a specific page or information, please don't hesitate to reach out to us.
            </p>
            <Link href="/contact">
              <motion.button 
                className={`px-6 py-3 rounded-full font-medium ${
                  isDark 
                    ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                    : 'bg-amber-500 hover:bg-amber-600 text-white'
                } transition-colors duration-300`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Contact Us
              </motion.button>
            </Link>
          </div>
          
          {/* XML Sitemap Information */}
          <div className="mt-16">
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              XML Sitemap
            </h3>
            <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
              Looking for our XML sitemap for SEO purposes? You can find it at:
              <a 
                href="https://SociLume.com/sitemap.xml"
                className={`block mt-2 ${
                  isDark 
                    ? 'text-indigo-400 hover:text-indigo-300' 
                    : 'text-amber-600 hover:text-amber-700'
                } font-mono`}
              >
                https://SociLume.com/sitemap.xml
              </a>
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SitemapContent; 