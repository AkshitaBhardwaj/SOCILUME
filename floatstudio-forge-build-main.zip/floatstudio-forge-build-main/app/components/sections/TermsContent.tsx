"use client";

import { motion } from 'framer-motion';
import { useTheme } from "next-themes";

const TermsContent = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-950' : 'bg-white'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <h1 className={`text-3xl md:text-4xl font-bold mb-8 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Terms of <span className={isDark ? "text-indigo-400" : "text-amber-500"}>Service</span>
          </h1>
          
          <div className={`prose max-w-none ${isDark ? 'prose-invert' : ''}`}>
            <p className="lead">Last Updated: May 15, 2023</p>
            
            <p>
              Please read these Terms of Service ("Terms") carefully before using the SociLume website
              or any services provided by SociLume ("Company", "we", "us", or "our").
            </p>

            <h2>1. Acceptance of Terms</h2>
            
            <p>
              By accessing or using our website at <a href="https://SociLume.com">SociLume.com</a> ("Site") 
              or any of our services, you agree to be bound by these Terms. If you do not agree to all the terms and 
              conditions of this agreement, you may not access the Site or use any services.
            </p>
            
            <h2>2. Changes to Terms</h2>
            
            <p>
              We reserve the right to modify these Terms at any time. We will always post the most current version on our 
              Site and indicate the date of the last revision. Your continued use of the Site after we post any modifications
              to the Terms will constitute your acknowledgment of the modifications and your consent to abide and be bound 
              by the modified Terms.
            </p>
            
            <h2>3. Services</h2>
            
            <p>
              SociLume provides web design, development, and related digital services ("Services") as described on our 
              Site. We reserve the right to modify, suspend, or discontinue any part of the Services at any time without 
              notice or liability.
            </p>
            
            <h2>4. Account Registration</h2>
            
            <p>
              Some features of our Services may require you to register for an account. You must provide accurate and 
              complete information and keep your account information updated. You are responsible for maintaining the 
              confidentiality of your account and password and for restricting access to your computer, and you agree to 
              accept responsibility for all activities that occur under your account.
            </p>
            
            <h2>5. Client Obligations</h2>
            
            <p>
              If you are a client engaging our Services, you agree to:
            </p>
            
            <ul>
              <li>Provide accurate and complete information necessary for us to perform the Services</li>
              <li>Review and provide feedback on our work in a timely manner</li>
              <li>Obtain any necessary permissions or rights for materials you provide to us</li>
              <li>Make payments according to the agreed-upon schedule</li>
              <li>Use the deliverables in accordance with these Terms and any specific project agreement</li>
            </ul>
            
            <h2>6. Intellectual Property Rights</h2>
            
            <h3>6.1 Our Content</h3>
            
            <p>
              The Site and its original content, features, and functionality are owned by SociLume and are protected 
              by international copyright, trademark, patent, trade secret, and other intellectual property or proprietary 
              rights laws. You may not copy, modify, create derivative works, publicly display, publicly perform, republish, 
              or transmit any of the material on our Site without our prior written consent.
            </p>
            
            <h3>6.2 Client Content</h3>
            
            <p>
              You retain all rights to any content or materials you provide to us in connection with the Services. By 
              providing such content, you grant us a non-exclusive, worldwide, royalty-free license to use, reproduce, 
              modify, adapt, publish, translate, and distribute such content in connection with providing the Services 
              to you.
            </p>
            
            <h3>6.3 Project Deliverables</h3>
            
            <p>
              Upon full payment of all applicable fees, we will assign to you all rights to the final deliverables as 
              specified in our project agreement. This assignment does not include any third-party materials, our proprietary 
              tools or frameworks, or any preliminary designs or concepts not selected for final production.
            </p>
            
            <h2>7. Payments and Fees</h2>
            
            <p>
              Payment terms for our Services will be outlined in the specific project agreement between you and SociLume. 
              Unless otherwise specified:
            </p>
            
            <ul>
              <li>All fees are quoted in US dollars and are non-refundable</li>
              <li>For most projects, we require a deposit before beginning work</li>
              <li>Final deliverables will be released only upon full payment</li>
              <li>Late payments may incur additional fees or suspension of services</li>
            </ul>
            
            <h2>8. Limitation of Liability</h2>
            
            <p>
              In no event shall SociLume, its directors, employees, partners, agents, suppliers, or affiliates, be 
              liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, 
              loss of profits, data, use, goodwill, or other intangible losses, resulting from:
            </p>
            
            <ul>
              <li>Your access to or use of or inability to access or use the Services</li>
              <li>Any conduct or content of any third party on the Services</li>
              <li>Any content obtained from the Services</li>
              <li>Unauthorized access, use, or alteration of your transmissions or content</li>
            </ul>
            
            <p>
              Our liability is limited to the maximum extent permitted by law. In no case shall our liability exceed 
              the amount you have paid to us for the Services in the 12 months prior to the event giving rise to the liability.
            </p>
            
            <h2>9. Indemnification</h2>
            
            <p>
              You agree to defend, indemnify, and hold harmless SociLume, its directors, employees, partners, agents, 
              suppliers, and affiliates, from and against any and all claims, damages, obligations, losses, liabilities, 
              costs, or debt, and expenses (including but not limited to attorney's fees) arising from:
            </p>
            
            <ul>
              <li>Your use of and access to the Services</li>
              <li>Your violation of any term of these Terms</li>
              <li>Your violation of any third-party right, including without limitation any copyright, property, or privacy right</li>
              <li>Any claim that your content caused damage to a third party</li>
            </ul>
            
            <h2>10. Termination</h2>
            
            <p>
              We may terminate or suspend your account and access to the Services immediately, without prior notice or liability, 
              for any reason, including without limitation if you breach the Terms. Upon termination, your right to use the 
              Services will immediately cease.
            </p>
            
            <h2>11. Governing Law</h2>
            
            <p>
              These Terms shall be governed and construed in accordance with the laws of the State of California, without 
              regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will 
              not be considered a waiver of those rights.
            </p>
            
            <h2>12. Dispute Resolution</h2>
            
            <p>
              Any dispute arising out of or relating to these Terms or the Services shall first be attempted to be resolved 
              through good faith negotiations. If such dispute cannot be resolved within 30 days, it shall be submitted to 
              binding arbitration in San Francisco, California, in accordance with the rules of the American Arbitration Association.
            </p>
            
            <h2>13. Contact Us</h2>
            
            <p>
              If you have any questions about these Terms, please contact us at:
            </p>
            
            <p>
              SociLume<br />
              12A, Princess Street<br />
              Marine Lines, Mumbai-400002<br />
              Email: legal@SociLume.com<br />
              Phone: +91 8171556685
            </p>
          </div>
          
          <div className="mt-12 text-center">
            <a
              href="/contact"
              className={`inline-flex items-center px-6 py-3 rounded-full font-medium ${
                isDark 
                  ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                  : 'bg-amber-500 hover:bg-amber-600 text-white'
              } transition-colors duration-300`}
            >
              Questions? Contact Us
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TermsContent; 