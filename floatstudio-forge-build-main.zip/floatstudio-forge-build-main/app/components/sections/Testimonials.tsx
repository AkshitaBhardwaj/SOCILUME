"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { Star } from 'lucide-react';

const Testimonials = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      id: "1",
      name: "Reena G.",
      role: "Boutique Owner",
      content: "Socilume gave me a full website and Instagram strategy in 4 days. Now I get leads every week — and I didn't even write a single post.",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1974"
    },
    {
      id: "2",
      name: "Ali T.",
      role: "Fitness Coach",
      content: "I had zero time to manage marketing. Their AI tools post for me. The influencer they found got me 13K views in 2 days.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974"
    }
  ];

  const handleDotClick = (index: number) => {
    setCurrentIndex(index);
  };

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-900' : 'bg-[#FAFAFA]'} transition-colors duration-300`}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
            Trusted by Entrepreneurs, Creators & Small Business Owners
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Here's what our clients say about their experience with Socilume and SocyU.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {/* Testimonial Cards */}
          <div className="relative">
            <motion.div 
              className="flex"
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: 1,
                x: `-${currentIndex * 100}%` 
              }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            >
              {testimonials.map((testimonial) => (
                <div 
                  key={testimonial.id} 
                  className="w-full flex-shrink-0 px-4"
                >
                  <motion.div 
                    className={`p-8 rounded-xl ${
                      isDark 
                        ? 'bg-gray-800 border border-gray-700' 
                        : 'bg-white shadow-xl'
                    }`}
                    initial={{ scale: 0.95, opacity: 0.8 }}
                    animate={{ 
                      scale: 1,
                      opacity: 1
                    }}
                    transition={{ duration: 0.5 }}
                  >
                    <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
                      <div className="md:w-1/4 flex-shrink-0">
                        <img 
                          src={testimonial.image} 
                          alt={testimonial.name}
                          className="w-24 h-24 rounded-full object-cover mx-auto border-4 border-white shadow-lg"
                        />
                      </div>
                      <div className="md:w-3/4 text-center md:text-left">
                        <div className="flex justify-center md:justify-start mb-6">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              size={18}
                              className={`${isDark ? 'fill-indigo-400 text-indigo-400' : 'fill-[#FFB700] text-[#FFB700]'}`}
                            />
                          ))}
                        </div>
                        <p className={`text-xl italic mb-6 ${isDark ? 'text-gray-200' : 'text-gray-700'}`}>
                          "{testimonial.content}"
                        </p>
                        <div>
                          <h4 className={`font-bold text-lg ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                            {testimonial.name}
                          </h4>
                          <p className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                            {testimonial.role}
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Navigation */}
          <div className="flex justify-center mt-8 items-center">
            <motion.button
              onClick={handlePrevious}
              className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${
                isDark 
                  ? 'bg-gray-800 text-white hover:bg-gray-700' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-5 w-5" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M15 19l-7-7 7-7" 
                />
              </svg>
            </motion.button>
            
            <div className="flex space-x-2">
              {testimonials.map((_, index) => (
                <motion.button
                  key={index}
                  onClick={() => handleDotClick(index)}
                  className={`w-3 h-3 rounded-full ${
                    currentIndex === index
                      ? isDark 
                        ? 'bg-indigo-500' 
                        : 'bg-[#FFB700]'
                      : isDark 
                        ? 'bg-gray-700' 
                        : 'bg-gray-300'
                  }`}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                />
              ))}
            </div>
            
            <motion.button
              onClick={handleNext}
              className={`w-10 h-10 rounded-full flex items-center justify-center ml-4 ${
                isDark 
                  ? 'bg-gray-800 text-white hover:bg-gray-700' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-5 w-5" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M9 5l7 7-7 7" 
                />
              </svg>
            </motion.button>
          </div>

          {/* Video Testimonial CTA */}
          {/* <motion.div 
            className="mt-16 text-center"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            viewport={{ once: true }}
          >
            <a 
              href="/contact" 
              className={`inline-flex items-center px-6 py-3 rounded-full font-medium ${
                isDark 
                  ? 'bg-indigo-500 hover:bg-indigo-600 text-white' 
                  : 'bg-[#FFB700] hover:bg-[#FFB700]/90 text-white'
              } transition-colors duration-300`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
              </svg>
              {/* Watch Video Testimonials
            </a>
          </motion.div>
           */}
        </div>
      </div>
    </section>
  );
};

export default Testimonials; 