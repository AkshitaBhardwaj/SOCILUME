"use client";

import React from 'react';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";
import { Rocket, Bot, Gift, BarChart2 } from 'lucide-react';

const WhyChooseUs = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section className={`py-24 ${isDark ? 'bg-gray-900' : 'bg-[#FAFAFA]'} transition-colors duration-300`} id="why-choose-us-section">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          {/* Problem Section */}
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 
              id="why-choose-us-heading"
              className={`text-3xl md:text-4xl font-bold mb-6 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}
            >
              Why Most Small Businesses Stay Invisible Online
            </h2>
            <div className="flex justify-center mb-8">
              <div className={`h-1 w-24 ${isDark ? 'bg-indigo-500' : 'bg-[#FFB700]'} rounded-full`}></div>
            </div>
            <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-12">
              <motion.div 
                className={`p-6 rounded-lg ${isDark ? 'bg-gray-800' : 'bg-white'} shadow-lg flex items-center gap-4 w-full md:w-auto`}
                whileHover={{ y: -5 }}
                transition={{ duration: 0.2 }}
              >
                <BarChart2 className={`h-10 w-10 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />
                <div className="text-left">
                  <h3 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>75%</h3>
                  <p className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>of SMBs still don't have a working marketing funnel</p>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Solution Section */}
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h2 className={`text-3xl md:text-4xl font-bold mb-8 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
              Socilume Solves This — <span className={isDark ? 'text-indigo-400' : 'text-[#FFB700]'}>All-In-One, Done-For-You</span>
            </h2>
          </motion.div>

          {/* 3 Columns */}
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {/* Column 1: Website in Days */}
            <motion.div 
              className={`p-8 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white shadow-xl'} text-center`}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div className="mb-6 flex justify-center">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  isDark ? 'bg-indigo-500/20' : 'bg-[#FFB700]/10'
                }`}>
                  <Rocket className={`h-8 w-8 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />
                </div>
              </div>
              <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                🚀 Website in Days
              </h3>
              <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                We design your site — fast, beautiful, mobile-ready.
              </p>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                No freelancers. No delays. No tech skills needed.
              </p>
            </motion.div>

            {/* Column 2: AI Marketing */}
            <motion.div 
              className={`p-8 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white shadow-xl'} text-center`}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div className="mb-6 flex justify-center">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  isDark ? 'bg-indigo-500/20' : 'bg-[#FFB700]/10'
                }`}>
                  <Bot className={`h-8 w-8 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />
                </div>
              </div>
              <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                🤖 AI Marketing
              </h3>
              <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                Our AI creates content, connects you to influencers, and runs campaigns.
              </p>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                No freelancers. No delays. No tech skills needed.
              </p>
            </motion.div>

            {/* Column 3: Lifetime Free Tools */}
            <motion.div 
              className={`p-8 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white shadow-xl'} text-center`}
              variants={itemVariants}
              whileHover={{ y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div className="mb-6 flex justify-center">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  isDark ? 'bg-indigo-500/20' : 'bg-[#FFB700]/10'
                }`}>
                  <Gift className={`h-8 w-8 ${isDark ? 'text-indigo-400' : 'text-[#FFB700]'}`} />
                </div>
              </div>
              <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-[#2C2C54]'}`}>
                💸 Lifetime Free Tools
              </h3>
              <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                You get full access to SocyU — forever. No monthly fees, ever.
              </p>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                No freelancers. No delays. No tech skills needed.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs; 