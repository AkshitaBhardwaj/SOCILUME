import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTheme } from 'next-themes';
import { ChevronRight, Home } from 'lucide-react';
import JsonLdSchema from './JsonLdSchema';

interface BreadcrumbsProps {
  homeElement?: React.ReactNode;
  separator?: React.ReactNode;
  containerClasses?: string;
  listClasses?: string;
  activeItemClasses?: string;
  capitalizeLinks?: boolean;
}

/**
 * Breadcrumbs Component
 * 
 * Displays a breadcrumb navigation path based on the current URL
 * Includes structured data for SEO
 */
const Breadcrumbs = ({
  homeElement = <Home size={16} />,
  separator = <ChevronRight size={16} />,
  containerClasses = 'py-4',
  listClasses = 'flex items-center space-x-2 text-sm',
  activeItemClasses = 'font-medium',
  capitalizeLinks = true
}: BreadcrumbsProps) => {
  const pathname = usePathname();
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  
  // Skip rendering breadcrumbs on homepage or if pathname is null
  if (!pathname || pathname === '/') {
    return null;
  }
  
  // Generate breadcrumb items from path
  const pathSegments = pathname.split('/').filter(segment => segment !== '');
  
  // Create breadcrumb items array for display
  const breadcrumbItems = pathSegments.map((segment, index) => {
    const href = `/${pathSegments.slice(0, index + 1).join('/')}`;
    const isLast = index === pathSegments.length - 1;
    
    // Format the label (replace hyphens with spaces and capitalize)
    let label = segment.replace(/-/g, ' ');
    if (capitalizeLinks) {
      label = label
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    }
    
    return {
      href,
      label,
      isLast
    };
  });
  
  // Create schema data for structured data
  const schemaData = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://socilume.com"
      },
      ...breadcrumbItems.map((item, index) => ({
        "@type": "ListItem",
        "position": index + 2,
        "name": item.label,
        "item": `https://socilume.com${item.href}`
      }))
    ]
  };
  
  return (
    <>
      <nav aria-label="Breadcrumb" className={containerClasses}>
        <ol className={listClasses}>
          <li>
            <Link 
              href="/"
              className={`flex items-center hover:${isDark ? 'text-indigo-400' : 'text-[#FFB700]'} transition-colors`}
              aria-label="Home"
            >
              {homeElement}
            </Link>
          </li>
          
          {breadcrumbItems.map((item, index) => (
            <li key={index} className="flex items-center">
              <span className={`mx-2 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} aria-hidden="true">
                {separator}
              </span>
              
              {item.isLast ? (
                <span className={`${activeItemClasses} ${isDark ? 'text-white' : 'text-[#2C2C54]'}`} aria-current="page">
                  {item.label}
                </span>
              ) : (
                <Link 
                  href={item.href}
                  className={`hover:${isDark ? 'text-indigo-400' : 'text-[#FFB700]'} transition-colors`}
                >
                  {item.label}
                </Link>
              )}
            </li>
          ))}
        </ol>
      </nav>
      
      {/* Add structured data */}
      <JsonLdSchema type="BreadcrumbList" data={schemaData} />
    </>
  );
};

export default Breadcrumbs; 