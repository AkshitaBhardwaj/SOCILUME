"use client";

import { useTheme } from "next-themes";
import NewsletterSubscribe from "./NewsletterSubscribe";

const FooterNewsletter = () => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div className={`w-full max-w-md rounded-xl p-6 ${isDark ? 'bg-gray-800/50' : 'bg-gray-100'}`}>
      <h3 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
        Stay in the Loop
      </h3>
      <p className={`text-sm mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
        Subscribe to receive updates, design tips, and exclusive offers.
      </p>
      <NewsletterSubscribe compact={true} />
    </div>
  );
};

export default FooterNewsletter; 