import Script from 'next/script';

interface JsonLdSchemaProps {
  type: 'Organization' | 'WebSite' | 'WebPage' | 'Service' | 'FAQPage' | 'BreadcrumbList' | 'Product';
  data: any;
}

/**
 * JsonLdSchema Component
 * 
 * Renders JSON-LD structured data for better SEO and rich search results
 * 
 * @param {string} type - The schema type (Organization, WebSite, etc.)
 * @param {object} data - The schema data
 */
const JsonLdSchema = ({ type, data }: JsonLdSchemaProps) => {
  // Base organization data
  const organizationData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "SociLume",
    "url": "https://socilume.com",
    "logo": "https://socilume.com/logo.png",
    "sameAs": [
      "https://www.facebook.com/socilume",
      "https://www.instagram.com/socilume",
      "https://twitter.com/socilume",
      "https://www.linkedin.com/company/socilume"
    ],
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-800-123-4567",
      "contactType": "customer service",
      "availableLanguage": ["English"]
    }
  };
  
  // Base website data
  const websiteData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "https://socilume.com",
    "name": "SociLume",
    "description": "Premium website building and AI marketing services for businesses of all sizes.",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://socilume.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };
  
  // Determine which schema to use
  let schemaData = {};
  
  switch (type) {
    case 'Organization':
      schemaData = { ...organizationData, ...data };
      break;
    case 'WebSite':
      schemaData = { ...websiteData, ...data };
      break;
    default:
      schemaData = {
        "@context": "https://schema.org",
        "@type": type,
        ...data
      };
  }
  
  return (
    <Script
      id={`jsonld-${type.toLowerCase()}`}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
    />
  );
};

export default JsonLdSchema; 