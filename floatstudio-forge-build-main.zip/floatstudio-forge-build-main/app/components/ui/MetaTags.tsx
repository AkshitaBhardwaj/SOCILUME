import Head from 'next/head';

interface MetaTagsProps {
  title: string;
  description: string;
  keywords?: string[];
  ogImage?: string;
  ogImageAlt?: string;
  ogType?: string;
  canonical?: string;
  twitterCard?: string;
  noIndex?: boolean;
}

/**
 * MetaTags Component
 * 
 * Renders SEO meta tags for dynamic pages
 */
const MetaTags = ({
  title,
  description,
  keywords = [],
  ogImage = 'https://socilume.com/og-image.jpg',
  ogImageAlt = 'SociLume - Premium Website Building & AI Marketing Services',
  ogType = 'website',
  canonical = '',
  twitterCard = 'summary_large_image',
  noIndex = false
}: MetaTagsProps) => {
  // Format the title to include the brand name if not already included
  const formattedTitle = title.includes('SociLume') 
    ? title 
    : `${title} | SociLume`;
  
  // Generate canonical URL
  const canonicalUrl = canonical 
    ? canonical 
    : `https://socilume.com${typeof window !== 'undefined' ? window.location.pathname : ''}`;
  
  return (
    <Head>
      {/* Primary Meta Tags */}
      <title>{formattedTitle}</title>
      <meta name="description" content={description} />
      {keywords.length > 0 && (
        <meta name="keywords" content={keywords.join(', ')} />
      )}
      
      {/* Canonical Link */}
      <link rel="canonical" href={canonicalUrl} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={ogType} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:title" content={formattedTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={ogImage} />
      <meta property="og:image:alt" content={ogImageAlt} />
      <meta property="og:site_name" content="SociLume" />
      <meta property="og:locale" content="en_US" />
      
      {/* Twitter */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:url" content={canonicalUrl} />
      <meta name="twitter:title" content={formattedTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={ogImage} />
      <meta name="twitter:creator" content="@SociLume" />
      
      {/* No index directive if specified */}
      {noIndex && (
        <meta name="robots" content="noindex, nofollow" />
      )}
      
      {/* Additional meta tags for better SEO */}
      <meta name="author" content="SociLume" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta httpEquiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="theme-color" content="#2C2C54" />
    </Head>
  );
};

export default MetaTags; 