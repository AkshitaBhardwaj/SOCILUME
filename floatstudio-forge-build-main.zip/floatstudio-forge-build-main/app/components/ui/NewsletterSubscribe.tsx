"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from "next-themes";

interface NewsletterSubscribeProps {
  compact?: boolean;
}

const NewsletterSubscribe: React.FC<NewsletterSubscribeProps> = ({ compact = false }) => {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<{
    success?: boolean;
    message?: string;
  }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setStatus({
        success: false,
        message: "Please enter your email address."
      });
      return;
    }

    setIsSubmitting(true);
    setStatus({});

    try {
      const response = await fetch('https://api.socyu.com/api/newsletter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const result = await response.json();

      if (response.ok) {
        setStatus({
          success: true,
          message: result.message || "Thank you for subscribing to our newsletter!"
        });
        setEmail('');
      } else {
        setStatus({
          success: false,
          message: result.error || "Something went wrong. Please try again."
        });
      }
    } catch (error) {
      setStatus({
        success: false,
        message: "An error occurred. Please try again later."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (compact) {
    return (
      <div>
        {status.success ? (
          <motion.div 
            className={`text-sm ${isDark ? 'text-green-400' : 'text-green-600'}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {status.message}
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className={`flex-grow px-3 py-2 text-sm rounded-lg border ${
                  isDark 
                    ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-500' 
                    : 'bg-white border-gray-300 text-black placeholder:text-gray-400'
                }`}
              />
              <motion.button
                type="submit"
                disabled={isSubmitting}
                className={`px-4 py-2 text-sm rounded-lg font-medium text-white ${
                  isDark 
                    ? 'bg-indigo-500 hover:bg-indigo-600' 
                    : 'bg-amber-500 hover:bg-amber-600'
                } transition-colors duration-300`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {isSubmitting ? "..." : "Subscribe"}
              </motion.button>
            </div>
            
            {status.success === false && (
              <motion.div 
                className={`mt-2 text-xs ${isDark ? 'text-red-400' : 'text-red-600'}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                {status.message}
              </motion.div>
            )}
          </form>
        )}
      </div>
    );
  }

  return (
    <div className={`rounded-xl p-8 ${isDark ? 'bg-gray-900 border border-gray-800' : 'bg-white shadow-lg'}`}>
      <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
        Subscribe to Our Newsletter
      </h3>
      <p className={`mb-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
        Stay updated with our latest projects, design tips, and industry insights.
      </p>
      
      {status.success ? (
        <motion.div 
          className={`p-4 rounded-lg ${isDark ? 'bg-green-900/30 text-green-400' : 'bg-green-100 text-green-700'}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {status.message}
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              className={`flex-grow px-4 py-2 rounded-lg border ${
                isDark 
                  ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-500' 
                  : 'bg-white border-gray-300 text-black placeholder:text-gray-400'
              }`}
            />
            <motion.button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 py-2 rounded-lg font-medium text-white ${
                isDark 
                  ? 'bg-indigo-500 hover:bg-indigo-600' 
                  : 'bg-amber-500 hover:bg-amber-600'
              } transition-colors duration-300`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {isSubmitting ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Subscribing...
                </span>
              ) : "Subscribe"}
            </motion.button>
          </div>
          
          {status.success === false && (
            <motion.div 
              className={`mt-3 text-sm ${isDark ? 'text-red-400' : 'text-red-600'}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              {status.message}
            </motion.div>
          )}
        </form>
      )}
    </div>
  );
};

export default NewsletterSubscribe; 