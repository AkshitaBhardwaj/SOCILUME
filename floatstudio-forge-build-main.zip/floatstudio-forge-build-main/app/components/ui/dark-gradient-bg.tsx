"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";

export function DarkGradientBg() {
  const { theme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Avoid hydration mismatch
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  // Only show in dark mode
  if (theme !== "dark") return null;

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      <div className="absolute top-[-20%] left-[15%] w-[70vw] h-[50vh] rounded-full opacity-10 bg-gradient-to-r from-indigo-600 via-purple-700 to-pink-600 blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[15%] w-[60vw] h-[40vh] rounded-full opacity-5 bg-gradient-to-r from-cyan-600 via-blue-700 to-indigo-800 blur-[120px]" />
    </div>
  );
} 