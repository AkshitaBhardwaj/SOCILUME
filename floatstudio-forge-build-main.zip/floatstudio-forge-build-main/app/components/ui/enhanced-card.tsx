"use client";

import { ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useTheme } from "next-themes";

interface EnhancedCardProps {
  children: ReactNode;
  className?: string;
  delay?: number;
}

export function EnhancedCard({ children, className, delay = 0 }: EnhancedCardProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  
  return (
    <motion.div
      className={cn(
        "relative rounded-xl overflow-hidden transition-all",
        isDark 
          ? "bg-gray-900 border border-gray-800 hover:border-gray-700" 
          : "bg-white border border-gray-200 hover:border-gray-300",
        className
      )}
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ 
        duration: 0.4, 
        delay: delay,
        ease: "easeOut" 
      }}
      whileHover={{ 
        y: -5,
        transition: { duration: 0.2 }
      }}
    >
      <div className="relative z-10 p-6">
        {children}
      </div>
      
      {/* Subtle glow effect on hover (dark mode only) */}
      {isDark && (
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      )}
    </motion.div>
  );
} 