"use client";

import { ReactNode, useRef, useState } from "react";
import { cn } from "../../lib/utils";
import { motion } from "framer-motion";

interface FloatingCardProps {
  className?: string;
  children: ReactNode;
  glowColor?: string;
  rotateEffect?: boolean;
  delayAnimation?: number;
}

export function FloatingCard({
  className,
  children,
  glowColor = "from-indigo-500 via-purple-500 to-pink-500",
  rotateEffect = true,
  delayAnimation = 0,
}: FloatingCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!rotateEffect || !cardRef.current) return;
    
    const card = cardRef.current;
    const rect = card.getBoundingClientRect();
    
    // Center of the card
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    // Mouse distance from center
    const mouseX = e.clientX - centerX;
    const mouseY = e.clientY - centerY;
    
    // Rotation range (adjust these values for more/less rotation)
    const maxRotation = 10;
    const rotX = (mouseY / (rect.height / 2)) * -maxRotation;
    const rotY = (mouseX / (rect.width / 2)) * maxRotation;
    
    setRotateX(rotX);
    setRotateY(rotY);
  };

  const resetRotation = () => {
    setRotateX(0);
    setRotateY(0);
  };

  return (
    <motion.div
      ref={cardRef}
      className={cn(
        "premium-card relative overflow-hidden rounded-xl cursor-pointer",
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        resetRotation();
      }}
      onMouseMove={handleMouseMove}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.5, 
        delay: delayAnimation,
        type: "spring",
        stiffness: 100 
      }}
      style={{
        transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
        transformStyle: 'preserve-3d'
      }}
    >
      {/* Glow effect */}
      <div 
        className={cn(
          "absolute inset-0 opacity-0 blur-xl -z-10 bg-gradient-to-r",
          glowColor,
          isHovered && "opacity-30 transition-opacity duration-500"
        )}
      />
      
      {/* Border glow */}
      <div 
        className={cn(
          "absolute -inset-[1px] rounded-xl bg-gradient-to-r opacity-0 -z-5",
          glowColor,
          isHovered && "opacity-40 transition-opacity duration-500"
        )}
      />
      
      {/* Shimmer effect */}
      <div className={cn(
        "absolute inset-0 overflow-hidden rounded-xl opacity-0",
        isHovered && "opacity-100"
      )}>
        <div className="shimmer w-full h-full" />
      </div>

      {/* Card content with 3D effect */}
      <div className="card-3d-content relative z-10 p-6">
        {children}
      </div>
    </motion.div>
  );
} 