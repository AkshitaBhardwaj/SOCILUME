"use client";

import React, { useState, useEffect, useCallback, ReactNode } from "react";
import { useTheme } from "next-themes";
import { cn } from "../../lib/utils";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface PremiumCarouselProps {
  children: ReactNode[];
  autoPlay?: boolean;
  interval?: number;
  showArrows?: boolean;
  showDots?: boolean;
  className?: string;
}

export function PremiumCarousel({
  children,
  autoPlay = true,
  interval = 5000,
  showArrows = true,
  showDots = true,
  className,
}: PremiumCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const nextSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => 
      prevIndex === children.length - 1 ? 0 : prevIndex + 1
    );
  }, [children.length]);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? children.length - 1 : prevIndex - 1
    );
  }, [children.length]);

  useEffect(() => {
    if (!autoPlay || isHovering) return;
    
    const timer = setInterval(() => {
      nextSlide();
    }, interval);
    
    return () => clearInterval(timer);
  }, [autoPlay, interval, nextSlide, isHovering]);

  // Animation variants
  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 300 : -300,
      opacity: 0,
    }),
  };

  const [direction, setDirection] = useState(1);

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  const handleNextSlide = () => {
    setDirection(1);
    nextSlide();
  };

  const handlePrevSlide = () => {
    setDirection(-1);
    prevSlide();
  };

  return (
    <div 
      className={cn(
        "relative overflow-hidden rounded-xl",
        className
      )}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Glow effect for dark mode */}
      {isDark && (
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-indigo-500/20 via-purple-500/10 to-pink-500/20 blur-2xl opacity-30" />
      )}
      
      {/* Main carousel */}
      <div className="relative overflow-hidden rounded-xl">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
            }}
            className="w-full"
          >
            {children[currentIndex]}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Arrows */}
      {showArrows && (
        <>
          <button
            onClick={handlePrevSlide}
            className={cn(
              "absolute left-4 top-1/2 -translate-y-1/2 h-10 w-10",
              "flex items-center justify-center rounded-full",
              "bg-black/20 backdrop-blur-sm text-white",
              "hover:bg-black/30 transition-all duration-200",
              "dark:bg-white/10 dark:hover:bg-white/20",
              "focus:outline-none z-10"
            )}
            aria-label="Previous slide"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={handleNextSlide}
            className={cn(
              "absolute right-4 top-1/2 -translate-y-1/2 h-10 w-10",
              "flex items-center justify-center rounded-full",
              "bg-black/20 backdrop-blur-sm text-white",
              "hover:bg-black/30 transition-all duration-200",
              "dark:bg-white/10 dark:hover:bg-white/20",
              "focus:outline-none z-10"
            )}
            aria-label="Next slide"
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}

      {/* Dots */}
      {showDots && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
          {children.map((_, index) => (
            <button
              key={index}
              onClick={() => handleDotClick(index)}
              className={cn(
                "w-2.5 h-2.5 rounded-full transition-all duration-300",
                currentIndex === index 
                  ? "bg-white w-8" 
                  : "bg-white/50 hover:bg-white/80",
                "dark:bg-indigo-400/70 dark:hover:bg-indigo-400"
              )}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
} 