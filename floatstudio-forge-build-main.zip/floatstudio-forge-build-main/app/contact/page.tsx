import { Metadata } from "next";
import ContactForm from "../components/sections/ContactForm";

export const metadata: Metadata = {
  title: "Contact Us | SociLume - Web Design & Development Agency",
  description: "Get in touch with SociLume's team of expert web designers and developers. We're here to bring your digital vision to life with cutting-edge solutions.",
  keywords: ["contact SociLume", "web design agency contact", "hire web developers", "website development inquiry"],
  alternates: {
    canonical: "https://SociLume.com/contact",
  },
  openGraph: {
    title: "Contact SociLume - Premium Web Design & Development",
    description: "Reach out to our team of experts for your next digital project. We're ready to transform your vision into reality.",
    url: "https://SociLume.com/contact",
    siteName: "SociLume",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Contact SociLume - Premium Web Design & Development",
    description: "Reach out to our team of experts for your next digital project. We're ready to transform your vision into reality.",
  },
  robots: {
    index: true,
    follow: true,
  }
};

export default function ContactPage() {
  return (
    <main className="min-h-screen">
      <ContactForm />
    </main>
  );
} 