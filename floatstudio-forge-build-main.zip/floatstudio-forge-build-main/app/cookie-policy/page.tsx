import { Metadata } from "next";
import CookiePolicyContent from "../components/sections/CookiePolicyContent";

export const metadata: Metadata = {
  title: "Cookie Policy | SociLume - Your Data Choices",
  description: "Learn about how SociLume uses cookies, what data they collect, and how you can control your cookie preferences for an optimized browsing experience.",
  keywords: ["cookie policy", "cookies", "website cookies", "data tracking", "privacy settings"],
  alternates: {
    canonical: "https://SociLume.com/cookie-policy",
  },
  openGraph: {
    title: "Cookie Policy | SociLume - Your Data Choices",
    description: "Learn about how SociLume uses cookies, what data they collect, and how you can control your cookie preferences.",
    url: "https://SociLume.com/cookie-policy",
    siteName: "SociLume",
    locale: "en_US",
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  }
};

export default function CookiePolicyPage() {
  return (
    <main className="min-h-screen">
      <CookiePolicyContent />
    </main>
  );
} 