import "./globals.css";
import type { Metadata } from "next";
import { Inter, Montserrat } from "next/font/google";
import { cn } from "@/lib/utils";
import Script from "next/script";
import { ThemeProvider } from "../components/theme-provider";
import { DarkGradientBg } from "./components/ui/dark-gradient-bg";

// Load fonts
const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap"
});

const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
  display: "swap"
});

// SEO Metadata configuration
export const metadata: Metadata = {
  metadataBase: new URL('https://SociLume.dev'),
  title: {
    template: '%s | SociLume - Premium Web Development',
    default: 'SociLume - Premium Next.js Website Development Services',
  },
  description: "Transform your vision into a high-performance, SEO-optimized Next.js website with stunning animations and dark mode. We craft bespoke web solutions that drive growth and deliver exceptional user experiences.",
  applicationName: "SociLume",
  keywords: ["Next.js development", "web development", "custom websites", "SEO optimization", "premium websites", "React development", "responsive design", "e-commerce websites", "UI/UX design", "website performance", "dark mode website", "animation effects", "premium UI"],
  creator: "SociLume",
  publisher: "SociLume",
  authors: [{ name: "SociLume", url: "https://SociLume.dev" }],
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  category: "Technology",
  alternates: {
    canonical: '/',
    languages: {
      'en-US': '/en-US',
    },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://SociLume.dev",
    title: "SociLume - Premium Next.js Website Development Services",
    description: "Transform your vision into a high-performance, SEO-optimized Next.js website with stunning animations and dark mode. We craft bespoke web solutions that drive growth and deliver exceptional user experiences.",
    siteName: "SociLume",
    images: [
      {
        url: "https://SociLume.dev/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "SociLume - Premium Next.js Website Development",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "SociLume - Premium Next.js Website Development Services",
    description: "Transform your vision into a high-performance, SEO-optimized Next.js website with stunning animations and dark mode. We craft bespoke web solutions that drive growth and deliver exceptional user experiences.",
    creator: "@SociLume",
    images: ["https://SociLume.dev/twitter-image.jpg"],
  },
  verification: {
    google: "google-site-verification-code", // Replace with your verification code
  },
  robots: {
    index: true,
    follow: true,
    nocache: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  manifest: "/site.webmanifest",
  icons: {
    icon: [
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" }
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }
    ],
    other: [
      { url: "/safari-pinned-tab.svg", rel: "mask-icon" }
    ]
  },
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0f172a" }
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html 
      lang="en" 
      suppressHydrationWarning 
      className={`${inter.variable} ${montserrat.variable}`}
    >
      <body className={cn(inter.className, "min-h-screen antialiased transition-colors duration-300")}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <DarkGradientBg />
          {children}
        </ThemeProvider>
        
        {/* Structured Data (JSON-LD) for organization */}
        <Script
          id="organization-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "SociLume",
              "description": "Premium Next.js Website Development Services with stunning animations and dark mode",
              "image": "https://SociLume.dev/logo.jpg",
              "url": "https://SociLume.dev",
              "sameAs": [
                "https://twitter.com/SociLume",
                "https://www.linkedin.com/company/SociLume",
                "https://github.com/SociLume"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "123 Web Dev Lane",
                "addressLocality": "Tech City",
                "addressRegion": "Digital State",
                "postalCode": "10101",
                "addressCountry": "US"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "40.7128",
                "longitude": "-74.0060"
              },
              "email": "contact@SociLume.dev",
              "telephone": "+1-123-456-7890",
              "openingHours": "Mo,Tu,We,Th,Fr 09:00-17:00",
              "priceRange": "$$$",
              "areaServed": {
                "@type": "GeoCircle",
                "geoMidpoint": {
                  "@type": "GeoCoordinates",
                  "latitude": "40.7128",
                  "longitude": "-74.0060"
                },
                "geoRadius": "10000"
              },
              "foundingDate": "2020",
              "award": "Best Web Development Agency 2023",
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Web Development Services",
                "itemListElement": [
                  {
                    "@type": "OfferCatalog",
                    "name": "Web Design Services",
                    "itemListElement": [
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "Service",
                          "name": "Premium UI/UX Design"
                        }
                      },
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "Service",
                          "name": "Dark Mode Implementation"
                        }
                      },
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "Service",
                          "name": "Advanced Animation Effects"
                        }
                      }
                    ]
                  },
                  {
                    "@type": "OfferCatalog",
                    "name": "Web Development Services",
                    "itemListElement": [
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "Service",
                          "name": "Next.js Development"
                        }
                      },
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "Service",
                          "name": "E-commerce Development"
                        }
                      },
                      {
                        "@type": "Offer",
                        "itemOffered": {
                          "@type": "Service",
                          "name": "API Integration"
                        }
                      }
                    ]
                  }
                ]
              }
            })
          }}
        />

        {/* LocalBusiness structured data */}
        <Script
          id="localbusiness-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": "SociLume",
              "image": "https://SociLume.dev/logo.jpg",
              "url": "https://SociLume.dev",
              "telephone": "+1-123-456-7890",
              "priceRange": "$$$",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "123 Web Dev Lane",
                "addressLocality": "Tech City",
                "addressRegion": "Digital State",
                "postalCode": "10101",
                "addressCountry": "US"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "40.7128",
                "longitude": "-74.0060"
              },
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday"
                  ],
                  "opens": "09:00",
                  "closes": "17:00"
                }
              ],
              "sameAs": [
                "https://twitter.com/SociLume",
                "https://www.linkedin.com/company/SociLume",
                "https://github.com/SociLume"
              ]
            })
          }}
        />

        {/* Web services structured data */}
        <Script
          id="service-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Service",
              "serviceType": "Next.js Website Development",
              "provider": {
                "@type": "ProfessionalService",
                "name": "SociLume"
              },
              "description": "Premium Next.js website development services with stunning animations and dark mode for businesses looking to elevate their digital presence with high-performance, SEO-optimized websites.",
              "offers": {
                "@type": "Offer",
                "price": "Custom Quote",
                "priceCurrency": "USD"
              },
              "areaServed": {
                "@type": "GeoCircle",
                "geoMidpoint": {
                  "@type": "GeoCoordinates",
                  "latitude": "40.7128",
                  "longitude": "-74.0060"
                },
                "geoRadius": "Worldwide"
              },
              "termsOfService": "https://SociLume.dev/terms",
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Next.js Development Services",
                "itemListElement": [
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Enterprise Web Applications"
                    }
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "E-commerce Platforms"
                    }
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Dark Mode Implementation"
                    }
                  }
                ]
              }
            })
          }}
        />

        {/* Website structured data */}
        <Script
          id="website-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              "name": "SociLume",
              "url": "https://SociLume.dev",
              "potentialAction": {
                "@type": "SearchAction",
                "target": {
                  "@type": "EntryPoint",
                  "urlTemplate": "https://SociLume.dev/search?q={search_term_string}"
                },
                "query-input": "required name=search_term_string"
              }
            })
          }}
        />
      </body>
    </html>
  );
} 