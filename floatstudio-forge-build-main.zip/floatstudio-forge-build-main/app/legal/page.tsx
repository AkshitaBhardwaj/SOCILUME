import { Metadata } from "next";
import LegalContent from "../components/sections/LegalContent";

export const metadata: Metadata = {
  title: "Legal Information | SociLume - Policies & Agreements",
  description: "Access SociLume's legal information, including our Terms of Service, Privacy Policy, Cookie Policy, and more all in one place.",
  keywords: ["legal information", "website policies", "terms and conditions", "privacy", "SociLume legal"],
  alternates: {
    canonical: "https://SociLume.com/legal",
  },
  openGraph: {
    title: "Legal Information | SociLume - Policies & Agreements",
    description: "Access SociLume's legal information, including our Terms of Service, Privacy Policy, Cookie Policy, and more all in one place.",
    url: "https://SociLume.com/legal",
    siteName: "SociLume",
    locale: "en_US",
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  }
};

export default function LegalPage() {
  return (
    <main className="min-h-screen">
      <LegalContent />
    </main>
  );
} 