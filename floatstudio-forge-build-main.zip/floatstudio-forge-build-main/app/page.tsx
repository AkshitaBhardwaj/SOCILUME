import Navbar from "./components/sections/Navbar";
import Hero from "./components/sections/Hero";
import Features from "./components/sections/Features";
import HowItWorks from "./components/sections/HowItWorks";
import AboutUs from "./components/sections/AboutUs";
import Services from "./components/sections/Services";
import WhyChooseUs from "./components/sections/WhyChooseUs";
import OurProcess from "./components/sections/OurProcess";
import Portfolio from "./components/sections/Portfolio";
import Testimonials from "./components/sections/Testimonials";
import Cta from "./components/sections/Cta";
import Faqs from "./components/sections/Faqs";
import Footer from "./components/sections/Footer";
import Pricing from "./components/sections/Pricing";
import type { Metadata } from "next";
import Script from "next/script";

// Enhanced SEO metadata
export const metadata: Metadata = {
  title: "SociLume | Premium Website Building & AI Marketing | From $200",
  description: "Get your website built in days and marketed by AI. SociLume creates conversion-focused websites and provides AI-powered marketing tools to grow your business. Starting at just $200.",
  keywords: [
    // Primary keywords
    "website building service", "AI marketing tools", "affordable website design", 
    "business website development", "fast website creation", "AI content generation",
    "small business website", "website in days", "professional website design",
    
    // Long-tail keywords
    "website and marketing package", "AI marketing automation", "website design for small business",
    "affordable website with marketing", "custom website under $500", "AI social media management",
    "website design and SEO package", "business website with AI marketing", "website with free marketing tools",
    
    // Industry-specific
    "e-commerce website development", "service business website design", "local business website",
    "professional services website", "restaurant website design", "real estate website development",
    "healthcare website design", "SaaS website development", "consultant website design",
    
    // Feature-specific
    "mobile responsive website", "SEO-optimized website", "dark mode website design",
    "animated website elements", "website with contact forms", "lead generation website",
    "website with booking system", "AI content creation", "influencer marketing automation"
  ],
  authors: [{ name: "SociLume", url: "https://socilume.com" }],
  creator: "SociLume",
  publisher: "SociLume",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://socilume.com",
    title: "SociLume | Premium Website Building & AI Marketing | From $200",
    description: "Get your website built in days and marketed by AI. SociLume creates conversion-focused websites and provides AI-powered marketing tools to grow your business. Starting at just $200.",
    siteName: "SociLume",
    images: [
      {
        url: "https://socilume.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "SociLume - Premium Website Building & AI Marketing Services"
      }
    ]
  },
  twitter: {
    card: "summary_large_image",
    title: "SociLume | Premium Website Building & AI Marketing | From $200",
    description: "Get your website built in days and marketed by AI. SociLume creates conversion-focused websites and provides AI-powered marketing tools to grow your business.",
    creator: "@SociLume",
    images: ["https://socilume.com/twitter-image.jpg"],
  },
  alternates: {
    canonical: "https://socilume.com",
    languages: {
      'en-US': 'https://socilume.com/en-US',
    },
  },
  category: "Business",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
      'max-video-preview': -1,
    },
  },
  verification: {
    google: "google-site-verification-code",
    yandex: "yandex-verification-code",
  },
};

export default function Home() {
  return (
    <>
      <header className="z-50 relative">
        <Navbar />
      </header>
      
      <main className="min-h-screen" itemScope itemType="https://schema.org/WebPage">
        <section id="hero" aria-labelledby="hero-heading" itemProp="mainContentOfPage">
          <Hero />
        </section>
        
        <section id="about-us" aria-labelledby="about-us-heading" itemScope itemType="https://schema.org/AboutPage">
          <AboutUs />
        </section>
        
        <section id="services" aria-labelledby="services-heading" itemScope itemType="https://schema.org/Service">
          <Services />
        </section>
        
        <section id="features" aria-labelledby="features-heading">
          <Features />
        </section>
        
        <section id="why-choose-us" aria-labelledby="why-choose-us-heading">
          <WhyChooseUs />
        </section>
        
        <section id="pricing" aria-labelledby="pricing-heading" itemScope itemType="https://schema.org/Offer">
          <Pricing />
        </section>
        
        <section id="our-process" aria-labelledby="our-process-heading">
          <OurProcess />
        </section>
        
        <section id="how-it-works" aria-labelledby="how-it-works-heading">
          <HowItWorks />
        </section>
        
        <section id="portfolio" aria-labelledby="portfolio-heading" itemScope itemType="https://schema.org/CollectionPage">
          <Portfolio />
        </section>
        
        <section id="testimonials" aria-labelledby="testimonials-heading" itemScope itemType="https://schema.org/Review">
          <Testimonials />
        </section>
        
        <section id="faqs" aria-labelledby="faqs-heading" itemScope itemType="https://schema.org/FAQPage">
          <Faqs />
        </section>
        
        <section id="cta" aria-labelledby="cta-heading">
          <Cta />
        </section>
      </main>
      
      <footer className="mt-auto">
        <Footer />
      </footer>
      
      {/* Local Business Schema */}
      <Script
        id="local-business-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ProfessionalService",
            "name": "SociLume",
            "description": "Premium website building and AI marketing services for businesses of all sizes. We create your website in days and grow it with AI.",
            "image": "https://socilume.com/logo.png",
            "url": "https://socilume.com",
            "telephone": "+1-800-123-4567",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "123 Business Avenue",
              "addressLocality": "San Francisco",
              "addressRegion": "CA",
              "postalCode": "94103",
              "addressCountry": "US"
            },
            "geo": {
              "@type": "GeoCoordinates",
              "latitude": 37.7749,
              "longitude": -122.4194
            },
            "openingHoursSpecification": [
              {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                "opens": "09:00",
                "closes": "18:00"
              }
            ],
            "sameAs": [
              "https://www.facebook.com/socilume",
              "https://www.instagram.com/socilume",
              "https://twitter.com/socilume",
              "https://www.linkedin.com/company/socilume"
            ],
            "priceRange": "$$$"
          })
        }}
      />
      
      {/* Service Schema */}
      <Script
        id="service-schema"
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            "serviceType": "Website Development and AI Marketing",
            "provider": {
              "@type": "Organization",
              "name": "SociLume",
              "url": "https://socilume.com"
            },
            "areaServed": {
              "@type": "Country",
              "name": "United States"
            },
            "hasOfferCatalog": {
              "@type": "OfferCatalog",
              "name": "Website and Marketing Services",
              "itemListElement": [
                {
                  "@type": "Offer",
                  "itemOffered": {
                    "@type": "Service",
                    "name": "Starter Website Package",
                    "description": "1-Page Landing Website + SocyU access",
                    "price": "200",
                    "priceCurrency": "USD"
                  }
                },
                {
                  "@type": "Offer",
                  "itemOffered": {
                    "@type": "Service",
                    "name": "Business Website Package",
                    "description": "Full Website (5-7 pages) + Social Setup",
                    "price": "500",
                    "priceCurrency": "USD"
                  }
                },
                {
                  "@type": "Offer",
                  "itemOffered": {
                    "@type": "Service",
                    "name": "Pro Website Package",
                    "description": "Enterprise-level Site + Branding + SEO",
                    "price": "900",
                    "priceCurrency": "USD"
                  }
                }
              ]
            }
          })
        }}
      />
    </>
  );
} 