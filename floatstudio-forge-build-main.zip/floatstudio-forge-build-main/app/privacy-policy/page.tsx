import { Metadata } from "next";
import PrivacyPolicyContent from "../components/sections/PrivacyPolicyContent";

export const metadata: Metadata = {
  title: "Privacy Policy | SociLume - Data Protection Commitment",
  description: "Learn how SociLume protects and manages your personal data. Our privacy policy outlines our data collection practices, usage policies, and your rights.",
  keywords: ["privacy policy", "data protection", "GDPR compliance", "website privacy", "SociLume privacy"],
  alternates: {
    canonical: "https://SociLume.com/privacy-policy",
  },
  openGraph: {
    title: "Privacy Policy | SociLume - Data Protection Commitment",
    description: "Learn how SociLume protects and manages your personal data. Our privacy policy outlines our practices and your rights.",
    url: "https://SociLume.com/privacy-policy",
    siteName: "SociLume",
    locale: "en_US",
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  }
};

export default function PrivacyPolicyPage() {
  return (
    <main className="min-h-screen">
      <PrivacyPolicyContent />
    </main>
  );
} 