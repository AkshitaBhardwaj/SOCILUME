import { Metadata } from "next";
import SitemapContent from "../components/sections/SitemapContent";

export const metadata: Metadata = {
  title: "Sitemap | SociLume - Website Navigation Guide",
  description: "Explore all pages on the SociLume website through our comprehensive sitemap, designed to help you easily navigate our digital offerings.",
  keywords: ["sitemap", "site navigation", "website map", "SociLume pages", "website structure"],
  alternates: {
    canonical: "https://SociLume.com/sitemap",
  },
  openGraph: {
    title: "Sitemap | SociLume - Website Navigation Guide",
    description: "Explore all pages on the SociLume website through our comprehensive sitemap, designed to help you easily navigate our digital offerings.",
    url: "https://SociLume.com/sitemap",
    siteName: "SociLume",
    locale: "en_US",
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  }
};

export default function SitemapPage() {
  return (
    <main className="min-h-screen">
      <SitemapContent />
    </main>
  );
} 