import { Metadata } from "next";
import TermsContent from "../components/sections/TermsContent";

export const metadata: Metadata = {
  title: "Terms of Service | SociLume - Legal Agreements",
  description: "Read SociLume's Terms of Service to understand the legal agreement between you and our company when using our website and services.",
  keywords: ["terms of service", "terms and conditions", "legal agreement", "website terms", "service terms"],
  alternates: {
    canonical: "https://SociLume.com/terms-of-service",
  },
  openGraph: {
    title: "Terms of Service | SociLume - Legal Agreements",
    description: "Read SociLume's Terms of Service to understand the legal agreement between you and our company when using our website and services.",
    url: "https://SociLume.com/terms-of-service",
    siteName: "SociLume",
    locale: "en_US",
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  }
};

export default function TermsPage() {
  return (
    <main className="min-h-screen">
      <TermsContent />
    </main>
  );
} 