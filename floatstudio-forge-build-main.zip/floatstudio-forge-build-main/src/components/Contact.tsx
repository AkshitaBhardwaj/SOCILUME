
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Message sent!",
        description: "We'll get back to you as soon as possible.",
      });
      
      console.log("Form submitted:", formData);
      setFormData({ name: '', email: '', message: '' });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <section id="contact" className="py-24 bg-white relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-navy-50 rounded-bl-full"></div>
        <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-navy-50 rounded-tr-full"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-navy-800">Get in Touch</h2>
          <p className="text-lg text-navy-600 max-w-2xl mx-auto">
            Have questions or ready to start building your website? Contact us today!
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-12 max-w-6xl mx-auto">
          <div className="w-full md:w-1/2">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <input
                  type="text"
                  name="name"
                  id="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full bg-navy-50 border-navy-100 rounded-lg px-6 py-4 peer placeholder-transparent focus:outline-none focus:ring-2 focus:ring-gold-400 transition-all duration-300"
                  placeholder="Name"
                  required
                />
                <label 
                  htmlFor="name"
                  className="absolute left-6 -top-3 bg-white px-1 text-sm text-navy-600 transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-navy-400 peer-placeholder-shown:top-4 peer-focus:-top-3 peer-focus:text-sm peer-focus:text-navy-600"
                >
                  Name
                </label>
              </div>
              
              <div className="relative">
                <input
                  type="email"
                  name="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-navy-50 border-navy-100 rounded-lg px-6 py-4 peer placeholder-transparent focus:outline-none focus:ring-2 focus:ring-gold-400 transition-all duration-300"
                  placeholder="Email"
                  required
                />
                <label 
                  htmlFor="email"
                  className="absolute left-6 -top-3 bg-white px-1 text-sm text-navy-600 transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-navy-400 peer-placeholder-shown:top-4 peer-focus:-top-3 peer-focus:text-sm peer-focus:text-navy-600"
                >
                  Email
                </label>
              </div>
              
              <div className="relative">
                <textarea
                  name="message"
                  id="message"
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full bg-navy-50 border-navy-100 rounded-lg px-6 py-4 min-h-[150px] peer placeholder-transparent focus:outline-none focus:ring-2 focus:ring-gold-400 transition-all duration-300"
                  placeholder="Message"
                  required
                ></textarea>
                <label 
                  htmlFor="message"
                  className="absolute left-6 -top-3 bg-white px-1 text-sm text-navy-600 transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-navy-400 peer-placeholder-shown:top-4 peer-focus:-top-3 peer-focus:text-sm peer-focus:text-navy-600"
                >
                  Message
                </label>
              </div>
              
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-navy-800 hover:bg-navy-700 text-white py-6 font-medium floating-button"
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </Button>
            </form>
          </div>
          
          <div className="w-full md:w-1/2 flex flex-col justify-center">
            <div className="bg-navy-50 p-8 rounded-xl mb-8">
              <h3 className="text-2xl font-bold mb-4 text-navy-800">Our Sites</h3>
              <div className="space-y-4">
                <a 
                  href="https://socyu.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center text-navy-700 hover:text-navy-900 transition-colors"
                >
                  <span className="w-10 h-10 mr-3 bg-white rounded-full flex items-center justify-center shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
                    </svg>
                  </span>
                  SocyU.com
                </a>
                
                <a 
                  href="https://rentara.in" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center text-navy-700 hover:text-navy-900 transition-colors"
                >
                  <span className="w-10 h-10 mr-3 bg-white rounded-full flex items-center justify-center shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205l3 1m1.5.5l-1.5-.5M6.75 7.364V3h-3v18m3-13.636l10.5-3.819" />
                    </svg>
                  </span>
                  RentAra.in
                </a>
              </div>
            </div>
            
            <div className="bg-navy-50 p-8 rounded-xl">
              <h3 className="text-2xl font-bold mb-4 text-navy-800">Connect With Us</h3>
              <p className="text-navy-700 mb-6">
                Interested in learning more about SociLume? Reach out to us via email or social media.
              </p>
              <div className="space-y-4">
                <a 
                  href="mailto:ankushtagore@socyu.com" 
                  className="flex items-center text-navy-700 hover:text-navy-900 transition-colors"
                >
                  <span className="w-10 h-10 mr-3 bg-white rounded-full flex items-center justify-center shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                    </svg>
                  </span>
                  ankushtagore@socyu.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
