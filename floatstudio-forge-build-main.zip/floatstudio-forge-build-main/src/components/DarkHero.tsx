
import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";

const DarkHero = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // WebGL background animation
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const gl = canvas.getContext('webgl');
    if (!gl) return;

    // Resize canvas to fill window
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    window.addEventListener('resize', resize);
    resize();

    // Vertex shader
    const vertexShaderSource = `
      attribute vec2 a_position;
      void main() {
        gl_Position = vec4(a_position, 0, 1);
      }
    `;

    // Fragment shader with animated gradient
    const fragmentShaderSource = `
      precision mediump float;
      uniform vec2 u_resolution;
      uniform float u_time;

      vec3 colorA = vec3(0.95, 0.2, 0.4);  // Neon Pink
      vec3 colorB = vec3(0.2, 1.0, 1.0);   // Neon Cyan

      void main() {
        vec2 st = gl_FragCoord.xy / u_resolution;
        float noise = sin(st.x * 10.0 + u_time * 0.5) * sin(st.y * 10.0 + u_time * 0.3) * 0.25 + 0.25;
        
        float y = smoothstep(0.1, 0.9, st.y + sin(st.x * 3.0 + u_time * 0.2) * 0.15);
        y = y * 0.8 + noise * 0.2;
        
        vec3 color = mix(colorA, colorB, y);
        
        // Vignette effect
        float vignette = 1.0 - length(st - 0.5) * 1.0;
        vignette = smoothstep(0.0, 0.8, vignette);
        
        gl_FragColor = vec4(color * vignette * 0.15, 1.0);
      }
    `;

    // Create and compile shaders
    const vertexShader = gl.createShader(gl.VERTEX_SHADER)!;
    gl.shaderSource(vertexShader, vertexShaderSource);
    gl.compileShader(vertexShader);

    const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER)!;
    gl.shaderSource(fragmentShader, fragmentShaderSource);
    gl.compileShader(fragmentShader);

    // Create program
    const program = gl.createProgram()!;
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    gl.useProgram(program);

    // Create geometry - full screen quad
    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    const positions = [
      -1.0, -1.0,
       1.0, -1.0,
      -1.0,  1.0,
      -1.0,  1.0,
       1.0, -1.0,
       1.0,  1.0,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

    // Set up attributes
    const positionAttributeLocation = gl.getAttribLocation(program, "a_position");
    gl.enableVertexAttribArray(positionAttributeLocation);
    gl.vertexAttribPointer(positionAttributeLocation, 2, gl.FLOAT, false, 0, 0);

    // Set up uniforms
    const resolutionUniformLocation = gl.getUniformLocation(program, "u_resolution");
    gl.uniform2f(resolutionUniformLocation, canvas.width, canvas.height);

    const timeUniformLocation = gl.getUniformLocation(program, "u_time");
    
    // Render loop
    let startTime = Date.now();
    const render = () => {
      const time = (Date.now() - startTime) * 0.001; // time in seconds
      gl.uniform1f(timeUniformLocation, time);
      
      gl.clearColor(0.05, 0.06, 0.08, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      
      requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-16">
      {/* WebGL Background */}
      <canvas 
        ref={canvasRef} 
        className="absolute top-0 left-0 w-full h-full z-0"
      />
      
      {/* Background overlay */}
      <div className="absolute inset-0 z-10 bg-gradient-to-b from-slate-900/70 via-transparent to-slate-900/90"></div>
      
      {/* Floating design elements */}
      <div className="absolute inset-0 z-5 overflow-hidden">
        <motion.div 
          className="absolute top-[15%] left-[10%] w-32 h-32 rounded-full border border-pink-500/30 blur-sm"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
            rotate: [0, 90]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-[20%] right-[15%] w-48 h-48 rounded-full border border-cyan-500/20 blur-md"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.5, 0.2],
            rotate: [0, -90]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
        <motion.div 
          className="absolute top-[40%] right-[20%] w-24 h-24 rounded-full bg-gradient-to-r from-pink-500/10 to-cyan-500/10 blur-xl"
          animate={{
            y: [0, -30, 0],
            opacity: [0.3, 0.7, 0.3]
          }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-[30%] left-[20%] w-40 h-40 rounded-full bg-gradient-to-r from-purple-500/10 to-pink-500/10 blur-xl"
          animate={{
            y: [0, 30, 0],
            opacity: [0.2, 0.5, 0.2]
          }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        />
      </div>
      
      <div className="container mx-auto px-6 relative z-20">
        <div className="flex flex-col items-center text-center">
          <motion.h1 
            className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-[#FF3366] via-[#9E76FF] to-[#33FFFF]"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Launch Interactive Sites with Neon Flair—No Dev Team Required
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-gray-300 max-w-2xl mb-12"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Our experts build your premium website in just one week—calculate your savings now.
          </motion.p>
          
          <div className="flex flex-wrap justify-center gap-6">
            <motion.div
              className="hanging-button"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ 
                duration: 0.5,
                delay: 0.4,
                type: "spring",
                stiffness: 120,
                damping: 10
              }}
              whileHover={{
                y: [0, -5, 0],
                transition: { duration: 1, repeat: Infinity, repeatType: "mirror" }
              }}
            >
              <a href="#calculator">
                <Button className="bg-gradient-to-r from-[#FF3366] to-[#FF3366]/80 text-white font-medium px-8 py-7 text-lg border-b-4 border-[#FF3366]/50">
                  Calculate Your ROI
                </Button>
              </a>
            </motion.div>
            
            <motion.div
              className="floating-button"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ 
                duration: 0.5,
                delay: 0.6,
                type: "spring",
                stiffness: 100,
                damping: 8
              }}
              whileHover={{
                y: [0, -8, 0],
                transition: { duration: 1.3, repeat: Infinity, repeatType: "mirror" }
              }}
            >
              <Button 
                variant="outline" 
                className="text-[#33FFFF] border-[#33FFFF] hover:bg-[#33FFFF]/10 font-medium px-8 py-7 text-lg"
                onClick={() => document.getElementById('audit-modal')?.classList.remove('hidden')}
              >
                Request Free Audit
              </Button>
            </motion.div>
          </div>
        </div>
        
        {/* Recent projects showcase */}
        <motion.div 
          className="mt-16 max-w-5xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <h3 className="text-center text-xl text-white/70 mb-6">Websites we've built in the last month</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Project 1 */}
            <motion.div 
              className="relative overflow-hidden rounded-xl neo-glass-card group"
              whileHover={{ y: -5 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <img 
                src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b" 
                alt="Tech Project" 
                className="w-full h-48 object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900 to-transparent p-4">
                <h4 className="text-white font-bold">TechVision Portal</h4>
                <p className="text-xs text-white/70">Completed in 6 days</p>
              </div>
              <div className="absolute top-2 right-2">
                <span className="px-2 py-1 bg-green-500/80 text-white text-xs rounded-full">Live</span>
              </div>
            </motion.div>
            
            {/* Project 2 */}
            <motion.div 
              className="relative overflow-hidden rounded-xl neo-glass-card group"
              whileHover={{ y: -5 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <img 
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158" 
                alt="E-commerce Project" 
                className="w-full h-48 object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900 to-transparent p-4">
                <h4 className="text-white font-bold">LuxeStore</h4>
                <p className="text-xs text-white/70">Completed in 5 days</p>
              </div>
              <div className="absolute top-2 right-2">
                <span className="px-2 py-1 bg-green-500/80 text-white text-xs rounded-full">Live</span>
              </div>
            </motion.div>
            
            {/* Project 3 */}
            <motion.div 
              className="relative overflow-hidden rounded-xl neo-glass-card group"
              whileHover={{ y: -5 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-amber-500/20 to-red-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <img 
                src="https://images.unsplash.com/photo-1649972904349-6e44c42644a7" 
                alt="Finance Project" 
                className="w-full h-48 object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900 to-transparent p-4">
                <h4 className="text-white font-bold">FinanceFlow</h4>
                <p className="text-xs text-white/70">Completed in 7 days</p>
              </div>
              <div className="absolute top-2 right-2">
                <span className="px-2 py-1 bg-green-500/80 text-white text-xs rounded-full">Live</span>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
      
      {/* Down arrow */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ delay: 1, duration: 2, repeat: Infinity }}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3" />
        </svg>
      </motion.div>
      
      {/* Audit Modal */}
      <div id="audit-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm hidden">
        <div className="bg-slate-800 border border-slate-700 p-8 rounded-xl w-full max-w-md relative">
          <button 
            className="absolute top-4 right-4 text-gray-400 hover:text-white"
            onClick={() => document.getElementById('audit-modal')?.classList.add('hidden')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          
          <h2 className="text-2xl font-bold text-white mb-4">Free 15-Point Site Audit</h2>
          <p className="text-gray-300 mb-6">Share your details and our experts will analyze your current website with actionable improvement recommendations.</p>
          
          <form className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm text-gray-300 mb-1">Name</label>
              <input 
                type="text" 
                id="name" 
                className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white"
                placeholder="Your Name"
                required
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm text-gray-300 mb-1">Email</label>
              <input 
                type="email" 
                id="email" 
                className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white"
                placeholder="your@email.com"
                required
              />
            </div>
            
            <div>
              <label htmlFor="website" className="block text-sm text-gray-300 mb-1">Website URL</label>
              <input 
                type="url" 
                id="website" 
                className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white"
                placeholder="https://your-website.com"
                required
              />
            </div>
            
            <div>
              <label htmlFor="revenue" className="block text-sm text-gray-300 mb-1">Monthly Revenue</label>
              <input 
                type="number" 
                id="revenue" 
                className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white"
                placeholder="10000"
                required
              />
            </div>
            
            <Button className="w-full bg-gradient-to-r from-[#FF3366] to-[#33FFFF] text-white py-2 font-medium">
              Submit
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default DarkHero;
