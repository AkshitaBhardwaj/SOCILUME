
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";

interface FeatureNode {
  id: string;
  title: string;
  color: string;
  x: number;
  y: number;
  connections: string[];
}

const FeaturePlayground = () => {
  const [nodes, setNodes] = useState<FeatureNode[]>([
    { id: 'animations', title: 'Animations', color: '#FF3366', x: 100, y: 100, connections: ['forms'] },
    { id: 'forms', title: 'Forms', color: '#33FFFF', x: 300, y: 200, connections: ['calculators'] },
    { id: 'calculators', title: 'Calculators', color: '#9E76FF', x: 150, y: 300, connections: ['3d'] },
    { id: '3d', title: '3D Scenes', color: '#76FF9E', x: 400, y: 100, connections: ['animations'] },
  ]);
  
  const [activeNode, setActiveNode] = useState<string | null>(null);

  const handleNodeDrag = (id: string, x: number, y: number) => {
    setNodes(nodes.map(node => 
      node.id === id ? { ...node, x, y } : node
    ));
  };

  return (
    <section id="playground" className="min-h-screen bg-slate-900 py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text">
            Features Playground
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Discover how our features work together to create stunning websites. Drag the nodes to see their connections.
          </p>
        </div>
        
        <div className="relative h-[500px] max-w-4xl mx-auto bg-slate-800/50 rounded-lg backdrop-blur-sm border border-slate-700 shadow-xl">
          {/* Connection lines */}
          <svg className="absolute inset-0 w-full h-full z-10" xmlns="http://www.w3.org/2000/svg">
            {nodes.map(node => 
              node.connections.map(targetId => {
                const target = nodes.find(n => n.id === targetId);
                if (!target) return null;
                
                return (
                  <motion.path 
                    key={`${node.id}-${targetId}`}
                    d={`M${node.x + 50},${node.y + 50} C${(node.x + target.x)/2},${node.y} ${(node.x + target.x)/2},${target.y} ${target.x + 50},${target.y + 50}`}
                    stroke={`url(#gradient-${node.id}-${targetId})`}
                    strokeWidth="3"
                    fill="none"
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 1 }}
                    transition={{ duration: 1.5, type: "spring" }}
                  />
                );
              })
            )}
            
            {/* Gradients for connections */}
            <defs>
              {nodes.map(node => 
                node.connections.map(targetId => {
                  const target = nodes.find(n => n.id === targetId);
                  if (!target) return null;
                  
                  return (
                    <linearGradient 
                      key={`gradient-${node.id}-${targetId}`}
                      id={`gradient-${node.id}-${targetId}`}
                      x1="0%" 
                      y1="0%" 
                      x2="100%" 
                      y2="0%"
                    >
                      <stop offset="0%" stopColor={node.color} />
                      <stop offset="100%" stopColor={target.color} />
                    </linearGradient>
                  );
                })
              )}
            </defs>
          </svg>
          
          {/* Nodes */}
          {nodes.map((node) => (
            <motion.div
              key={node.id}
              className="absolute cursor-grab active:cursor-grabbing w-[100px] h-[100px] flex items-center justify-center rounded-lg shadow-lg border border-white/10 backdrop-blur-md"
              style={{ 
                backgroundColor: `${node.color}20`,
                borderColor: node.color,
                boxShadow: `0 0 15px ${node.color}80`
              }}
              animate={{ x: node.x, y: node.y }}
              drag
              dragConstraints={{ left: 0, right: 800, top: 0, bottom: 400 }}
              onDrag={(_, info) => {
                handleNodeDrag(node.id, info.point.x, info.point.y);
              }}
              onHoverStart={() => setActiveNode(node.id)}
              onHoverEnd={() => setActiveNode(null)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="text-white font-medium text-center">
                {node.title}
              </div>
            </motion.div>
          ))}
          
          {/* Preview panel */}
          <div className="absolute bottom-4 right-4 w-[300px] bg-slate-800 p-4 rounded-lg border border-slate-700">
            <h4 className="text-white font-medium mb-2">Preview</h4>
            <p className="text-gray-300 text-sm">
              {activeNode ? 
                `${activeNode.charAt(0).toUpperCase() + activeNode.slice(1)} activated. Combine with other features to create stunning websites.` : 
                "Hover over a node to see its description."
              }
            </p>
            <Button className="mt-4 w-full bg-gradient-to-r from-pink-500 to-cyan-500 text-white border-none">
              Try This Combination
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturePlayground;
