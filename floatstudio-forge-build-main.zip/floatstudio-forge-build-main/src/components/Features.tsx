
import { useState } from 'react';
import { motion } from 'framer-motion';

const Features = () => {
  const [activeFeature, setActiveFeature] = useState(0);
  
  const features = [
    {
      title: "Budget-Friendly Plans",
      description: "Premium designs at a fraction of custom development costs. Start from as low as $200.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" />
        </svg>
      )
    },
    // {
    //   title: "Drag-and-Drop Builder",
    //   description: "Intuitive design interface that makes creating beautiful sites effortless — no coding required.",
    //   icon: (
    //     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
    //       <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
    //     </svg>
    //   )
    // },
    {
      title: "Advanced Animations",
      description: "Stunning interactions, smooth transitions, and eye-catching effects bring your site to life.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.994 15.994 0 011.622-3.395m3.42 3.42a15.995 15.995 0 004.764-4.648l3.876-5.814a1.151 1.151 0 00-1.597-1.597L14.146 6.32a15.996 15.996 0 00-4.649 4.763m3.42 3.42a6.776 6.776 0 00-3.42-3.42" />
        </svg>
      )
    },
    {
      title: "Custom Domains & Hosting",
      description: "Connect your own domain and let us handle fast, reliable hosting for optimal site performance.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
        </svg>
      )
    },
    {
      title: "SEO & Performance",
      description: "Built-in optimization tools to help your site rank higher and load faster for better user experience.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
        </svg>
      )
    },
    {
      title: "24/7 Support",
      description: "Our expert team is always available to help you with any questions or technical issues.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" />
        </svg>
      )
    }
  ];

  return (
    <section id="features" className="py-24 bg-white relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 gradient-text">Powerful Features</h2>
          <p className="text-lg text-navy-600 max-w-2xl mx-auto">
            Everything you need to create stunning websites that convert visitors into customers.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="tilt-card bg-white rounded-xl p-6 h-full relative"
              onMouseEnter={() => setActiveFeature(index)}
              style={{
                transformStyle: "preserve-3d",
                transform: activeFeature === index ? "perspective(1000px) rotateX(5deg) rotateY(5deg)" : "perspective(1000px) rotateX(0) rotateY(0)",
                boxShadow: activeFeature === index ? "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" : "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"
              }}
            >
              <div className="flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-gold-100 text-navy-800">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-navy-800">{feature.title}</h3>
              <p className="text-navy-600">{feature.description}</p>
              
              {/* Floating accent */}
              <div className={`absolute -top-1 -right-1 w-3 h-12 bg-gold-400 rounded-full transition-all duration-300 ${activeFeature === index ? 'opacity-100' : 'opacity-0'}`}></div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-24 relative">
        <div className="text-center mb-12">
          <h3 className="text-2xl md:text-3xl font-bold mb-4 text-navy-800">Featured Projects</h3>
          <p className="text-navy-600 max-w-2xl mx-auto">
            See what our customers have built with SociLume
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8 overflow-x-auto px-6 py-8 pb-12 max-w-7xl mx-auto">
          <div className="min-w-[300px] md:min-w-[500px] bg-white rounded-xl shadow-xl overflow-hidden tilt-card">
            <img 
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085" 
              alt="SocyU Website" 
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h4 className="text-xl font-bold text-navy-800">SocyU</h4>
              <p className="text-navy-600 mb-4">Educational platform with interactive features</p>
              <a href="https://socyu.com" target="_blank" rel="noopener noreferrer" className="text-azure-600 hover:text-azure-800 font-medium">
                Visit Site →
              </a>
            </div>
          </div>
          
          <div className="min-w-[300px] md:min-w-[500px] bg-white rounded-xl shadow-xl overflow-hidden tilt-card">
            <img 
              src="https://images.unsplash.com/photo-1505533321630-975218a5f66f" 
              alt="RentAra Website" 
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h4 className="text-xl font-bold text-navy-800">RentAra</h4>
              <p className="text-navy-600 mb-4">Rental marketplace with seamless booking flow</p>
              <a href="https://rentara.in" target="_blank" rel="noopener noreferrer" className="text-azure-600 hover:text-azure-800 font-medium">
                Visit Site →
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
