import { Button } from "@/src/components/ui/button";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-16">
      {/* Background pattern */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white via-gold-50 to-white opacity-70"></div>
        <div className="absolute top-1/4 left-1/4 w-56 h-56 bg-azure-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-coral-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-float delay-500"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 space-y-6 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold text-navy-800 animate-fade-in">
              Build Your Brand <span className="text-gold-400">in days</span>,<br /> 
              <span className="relative inline-block">
                Impress
                <span className="absolute -bottom-2 left-0 right-0 h-1 bg-coral-400 transform"></span>
              </span> for a Lifetime.
            </h1>
            
            <p className="text-lg md:text-xl text-navy-600 max-w-lg animate-fade-in delay-150">
              The next-gen website builder for premium brands on a budget. Create stunning, animated websites without breaking the bank.
            </p>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4 pt-4 animate-fade-in delay-300">
              <a href="/contact" className="floating-button">
                <Button className="bg-coral-400 hover:bg-coral-500 text-white font-medium px-6 py-6 text-lg">
                  Get Started
                </Button>
              </a>
              <a href="#templates" className="hanging-button">
                <Button variant="outline" className="border-navy-300 text-navy-800 font-medium px-6 py-6 text-lg">
                  See Demos
                </Button>
              </a>
              <a href="#portfolio" className="hanging-button delay-150">
                <Button variant="ghost" className="text-navy-700 font-medium px-6 py-6 text-lg">
                  View Our Work
                </Button>
              </a>
            </div>
          </div>
          
          <div className="w-full md:w-1/2 mt-12 md:mt-0">
            <div className="relative">
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-gold-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-float"></div>
              <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-azure-200 rounded-full mix-blend-multiply filter blur-xl opacity-60 animate-float delay-500"></div>
              
              <div className="relative z-10 bg-white rounded-2xl shadow-2xl overflow-hidden tilt-card">
                <img 
                  src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158" 
                  alt="SociLume Website Builder Interface"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover rounded-t-2xl"
                />
                <div className="p-6 bg-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-montserrat font-bold text-navy-800">Premium Design</h3>
                      <p className="text-navy-600 text-sm">Ready in minutes, not months</p>
                    </div>
                    <div className="hanging-button">
                      <Button variant="outline" size="sm" className="border-gold-300 text-navy-800">
                        Try Now
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
