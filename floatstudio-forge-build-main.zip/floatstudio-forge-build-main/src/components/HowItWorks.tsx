
import { useEffect, useRef, useState } from 'react';

const HowItWorks = () => {
  const [activeStep, setActiveStep] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      
      const rect = sectionRef.current.getBoundingClientRect();
      const isVisible = rect.top < window.innerHeight / 2 && rect.bottom > window.innerHeight / 2;
      
      if (isVisible) {
        const scrollPosition = window.scrollY - rect.top + window.innerHeight / 2;
        const stepHeight = rect.height / 4;
        const newStep = Math.min(3, Math.floor(scrollPosition / stepHeight));
        setActiveStep(newStep);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const steps = [
    {
      title: "Design",
      description: "Choose from our premium templates designed by professional designers. Each template is fully customizable to match your brand.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10">
          <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.994 15.994 0 011.622-3.395m3.42 3.42a15.995 15.995 0 004.764-4.648l3.876-5.814a1.151 1.151 0 00-1.597-1.597L14.146 6.32a15.996 15.996 0 00-4.649 4.763m3.42 3.42a6.776 6.776 0 00-3.42-3.42" />
        </svg>
      )
    },
    {
      title: "Customize",
      description: "Drag and drop elements, change colors, fonts, and add your content with our intuitive builder. No coding required.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10">
          <path strokeLinecap="round" strokeLinejoin="round" d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 011.45.12l.773.774c.39.389.44 1.002.12 1.45l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.56.94 1.109v1.094c0 .55-.397 1.02-.94 1.11l-.893.149c-.425.07-.765.383-.93.78-.165.398-.143.854.107 1.204l.527.738c.32.447.269 1.06-.12 1.45l-.774.773a1.125 1.125 0 01-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.397.165-.71.505-.781.929l-.149.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.148-.894c-.071-.424-.384-.764-.781-.93-.398-.164-.854-.142-1.204.108l-.738.527c-.447.32-1.06.27-1.45-.12l-.773-.774a1.125 1.125 0 01-.12-1.45l.527-.737c.25-.35.273-.806.108-1.204-.165-.397-.505-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.109v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.107-1.204l-.527-.738a1.125 1.125 0 01.12-1.45l.773-.773a1.125 1.125 0 011.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.929l.15-.894z" />
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      )
    },
    {
      title: "Publish",
      description: "Go live with one click. Your website will be optimized for all devices and search engines automatically.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10">
          <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
        </svg>
      )
    },
    {
      title: "Grow",
      description: "Monitor performance, update content, and scale your site as your business grows. Our support team is here to help.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10">
          <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
        </svg>
      )
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-navy-50 relative overflow-hidden" ref={sectionRef}>
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-navy-800">How It Works</h2>
          <p className="text-lg text-navy-600 max-w-2xl mx-auto">
            Create your premium website in four simple steps
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-1 bg-navy-200"></div>
            
            {/* Timeline steps */}
            {steps.map((step, index) => (
              <div 
                key={index} 
                className={`relative flex flex-col md:flex-row items-start md:items-center gap-8 mb-24 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline marker */}
                <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 flex items-center justify-center">
                  <div 
                    className={`w-9 h-9 rounded-full border-4 transition-all duration-300 ${
                      index <= activeStep ? 'bg-coral-400 border-navy-50' : 'bg-navy-50 border-navy-200'
                    }`}
                  ></div>
                </div>
                
                {/* Content */}
                <div className={`pl-16 md:pl-0 w-full md:w-1/2 ${
                  index % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'
                }`}>
                  <div 
                    className={`bg-white p-6 rounded-xl shadow-lg transition-all duration-500 ${
                      index === activeStep ? 'transform translate-y-0 opacity-100' : 
                      index < activeStep ? 'transform -translate-y-4 opacity-70' : 
                      'transform translate-y-4 opacity-50'
                    }`}
                  >
                    <h3 className="flex items-center text-2xl font-bold mb-3 text-navy-800">
                      {index % 2 === 0 ? (
                        <>
                          {step.title}
                          <span className="ml-3 text-gold-400">{step.icon}</span>
                        </>
                      ) : (
                        <>
                          <span className="mr-3 text-gold-400">{step.icon}</span>
                          {step.title}
                        </>
                      )}
                    </h3>
                    <p className="text-navy-600">{step.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Founder Story */}
      <div className="mt-24 bg-white py-16">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="w-full md:w-1/2">
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1565307528294-f70f3c7094e0" 
                  alt="SociLume Founder" 
                  className="w-full h-auto"
                />
              </div>
            </div>
            <div className="w-full md:w-1/2">
              <h3 className="text-3xl font-bold mb-6 text-navy-800">Our Story</h3>
              <p className="text-lg text-navy-600 mb-6">
                SociLume was born from a simple observation: small businesses and creative entrepreneurs deserve beautiful websites without the premium price tag.
              </p>
              <p className="text-navy-600 mb-6">
                After years of building custom sites for clients who couldn't afford agency rates but deserved better than template sites, we created a platform that combines the best of both worlds.
              </p>
              <p className="text-navy-600">
                Today, we're proud to help brands of all sizes create stunning online experiences that capture their unique vision and connect with their audience.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
