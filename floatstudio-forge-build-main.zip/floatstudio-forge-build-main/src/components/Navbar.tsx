
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { X, Menu } from "lucide-react";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 px-6 md:px-12 transition-all duration-300 ${isScrolled ? 'bg-white/80 backdrop-blur-md shadow-md py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <a href="#" className="text-navy-800 font-montserrat font-bold text-2xl">
            Soci<span className="text-gold-400">Lume</span>
          </a>
        </div>
        
        <div className="hidden md:flex items-center space-x-8">
          <a href="#features" className="text-navy-700 hover:text-navy-900 font-medium transition-colors duration-200">Features</a>
          <a href="#how-it-works" className="text-navy-700 hover:text-navy-900 font-medium transition-colors duration-200">How It Works</a>
          <a href="#pricing" className="text-navy-700 hover:text-navy-900 font-medium transition-colors duration-200">Pricing</a>
          <a href="#templates" className="text-navy-700 hover:text-navy-900 font-medium transition-colors duration-200">Templates</a>
          <a href="/contact" className="text-navy-700 hover:text-navy-900 font-medium transition-colors duration-200">Contact</a>
        </div>
        
        <div className="flex items-center space-x-4">
          <a href="/contact" className="hanging-button hidden md:block">
            <Button className="bg-navy-800 hover:bg-navy-700 text-white">Get Started</Button>
          </a>
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMobileMenu}>
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg rounded-b-lg mt-2 py-4 px-6 absolute left-0 right-0 z-50 animate-fade-in">
          <div className="flex flex-col space-y-4">
            <a href="#features" className="text-navy-700 hover:text-navy-900 font-medium py-2" onClick={toggleMobileMenu}>Features</a>
            <a href="#how-it-works" className="text-navy-700 hover:text-navy-900 font-medium py-2" onClick={toggleMobileMenu}>How It Works</a>
            <a href="#pricing" className="text-navy-700 hover:text-navy-900 font-medium py-2" onClick={toggleMobileMenu}>Pricing</a>
            <a href="#templates" className="text-navy-700 hover:text-navy-900 font-medium py-2" onClick={toggleMobileMenu}>Templates</a>
            <a href="/contact" className="text-navy-700 hover:text-navy-900 font-medium py-2" onClick={toggleMobileMenu}>Contact</a>
            <a href="/contact" className="hanging-button">
              <Button className="w-full bg-navy-800 hover:bg-navy-700 text-white">Get Started</Button>
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
