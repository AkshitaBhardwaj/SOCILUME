
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const Pricing = () => {
  const [hoveredPlan, setHoveredPlan] = useState<number | null>(1); // Default to middle plan
  
  const plans = [
    {
      name: "Starter",
      price: "$200",
      description: "Perfect for simple brand introduction",
      features: [
        "1-pager site",
        "Brand introduction",
        "Contact section",
        "Mobile responsive",
        "Fast loading"
      ],
      cta: "Get Started"
    },
    {
      name: "Growth",
      popular: true,
      price: "$500",
      description: "Our most popular plan for growing businesses",
      features: [
        "Multi-section site",
        "Contact form",
        "Basic branding",
        "Mobile responsive",
        "SEO basics",
        "Analytics setup"
      ],
      cta: "Choose Growth"
    },
    {
      name: "Full Custom",
      price: "$900",
      description: "For businesses that need a premium presence",
      features: [
        "Premium UI",
        "Custom animations",
        "Third-party integrations",
        "Advanced SEO",
        "Performance optimization",
        "Content strategy",
        "Priority support"
      ],
      cta: "Go Custom"
    }
  ];

  return (
    <section id="pricing" className="py-24 bg-white relative">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 -left-24 w-64 h-64 bg-gold-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        <div className="absolute bottom-1/4 -right-24 w-64 h-64 bg-azure-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-navy-800">Simple, Transparent Pricing</h2>
          <p className="text-lg text-navy-600 max-w-2xl mx-auto">
            Choose the perfect plan for your business needs
          </p>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`w-full lg:w-1/3 bg-white rounded-2xl transition-all duration-500 relative ${
                hoveredPlan === index 
                  ? 'shadow-2xl transform -translate-y-4 scale-105 z-20' 
                  : 'shadow-lg'
              }`}
              onMouseEnter={() => setHoveredPlan(index)}
              onMouseLeave={() => setHoveredPlan(1)} // Keep middle plan highlighted by default
            >
              {plan.popular && (
                <div className="absolute -top-5 left-0 right-0 text-center">
                  <span className="bg-coral-400 text-white px-4 py-2 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className={`p-8 border-2 rounded-2xl h-full flex flex-col ${
                hoveredPlan === index ? 'border-gold-400' : 'border-gray-100'
              }`}>
                <h3 className="text-2xl font-bold text-navy-800 mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-navy-800">{plan.price}</span>
                </div>
                <p className="text-navy-600 mb-8">{plan.description}</p>
                
                <ul className="space-y-4 mb-8 flex-grow">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center">
                      <Check className="h-5 w-5 text-gold-400 mr-2" />
                      <span className="text-navy-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full ${
                    hoveredPlan === index 
                      ? 'bg-gold-400 hover:bg-gold-500 text-navy-800' 
                      : 'bg-navy-800 hover:bg-navy-700 text-white'
                  }`}
                >
                  {plan.cta}
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-navy-600">
            Need something custom? <a href="/contact" className="text-azure-600 hover:text-azure-800 font-medium">Contact us</a> for a personalized quote.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
