
import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const RevenueCalculator = () => {
  const { toast } = useToast();
  const [devCost, setDevCost] = useState(10000);
  const [monthlyHosting, setMonthlyHosting] = useState(150);
  const [traffic, setTraffic] = useState(5000);
  const [conversionRate, setConversionRate] = useState(2);
  const [averageOrder, setAverageOrder] = useState(100);
  const [lifetimeValue, setLifetimeValue] = useState(500);
  
  const [annualTraditional, setAnnualTraditional] = useState(0);
  const [annualFloat, setAnnualFloat] = useState(0);
  const [savings, setSavings] = useState(0);
  const [annualRevenue, setAnnualRevenue] = useState(0);
  const [totalValue, setTotalValue] = useState(0);

  const modalRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  
  // Calculate results
  useEffect(() => {
    // Using the updated algorithm from the requirements
    const SociLumeMonthly = 75;
    
    const calcAnnualTraditional = devCost + (monthlyHosting * 12);
    const calcAnnualFloat = SociLumeMonthly * 12;
    const calcSavings = calcAnnualTraditional - calcAnnualFloat;
    
    const annualOrders = traffic * (conversionRate / 100) * 12;
    const calcAnnualRevenue = annualOrders * averageOrder;
    const calcTotalValue = calcAnnualRevenue + (annualOrders * lifetimeValue);
    
    setAnnualTraditional(calcAnnualTraditional);
    setAnnualFloat(calcAnnualFloat);
    setSavings(calcSavings);
    setAnnualRevenue(calcAnnualRevenue);
    setTotalValue(calcTotalValue);
  }, [devCost, monthlyHosting, traffic, conversionRate, averageOrder, lifetimeValue]);
  
  const handleDownload = () => {
    modalRef.current?.classList.remove('hidden');
  };

  const handleSubmitEmail = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would normally send the email to your server
    // For now, we'll just show a toast message
    toast({
      title: "Report sent!",
      description: `Your ROI report has been sent to ${email}`,
      variant: "default",
    });
    modalRef.current?.classList.add('hidden');
    setEmail('');
  };

  const closeModal = () => {
    modalRef.current?.classList.add('hidden');
  };
  
  return (
    <section id="calculator" className="py-24 bg-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-slate-900 to-slate-900"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-8">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
          >
            Calculate Your ROI
          </motion.h2>
          <motion.p 
            className="text-lg text-gray-300 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            viewport={{ once: true }}
          >
            Stop guessing. Know exactly what you'll save—and earn—when our team builds your SociLume website in just one week.
          </motion.p>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8 max-w-6xl mx-auto">
          <div className="w-full lg:w-1/2 bg-slate-800/50 backdrop-blur-sm rounded-xl p-8 border border-slate-700 shadow-xl">
            <h3 className="text-2xl font-bold mb-6 text-white">Input Your Numbers</h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-gray-300 mb-2">Traditional Dev Cost ($)</label>
                <Input 
                  type="number" 
                  value={devCost} 
                  onChange={(e) => setDevCost(Number(e.target.value))} 
                  className="bg-slate-700 border-slate-600 text-white"
                />
                <input
                  type="range"
                  min="1000"
                  max="30000"
                  step="500"
                  value={devCost}
                  onChange={(e) => setDevCost(Number(e.target.value))}
                  className="w-full mt-2 accent-pink-500"
                />
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Monthly Hosting ($)</label>
                <Input 
                  type="number" 
                  value={monthlyHosting} 
                  onChange={(e) => setMonthlyHosting(Number(e.target.value))} 
                  className="bg-slate-700 border-slate-600 text-white"
                />
                <input
                  type="range"
                  min="10"
                  max="500"
                  step="10"
                  value={monthlyHosting}
                  onChange={(e) => setMonthlyHosting(Number(e.target.value))}
                  className="w-full mt-2 accent-cyan-500"
                />
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Monthly Visitors</label>
                <Input 
                  type="number" 
                  value={traffic} 
                  onChange={(e) => setTraffic(Number(e.target.value))} 
                  className="bg-slate-700 border-slate-600 text-white"
                />
                <input
                  type="range"
                  min="100"
                  max="50000"
                  step="100"
                  value={traffic}
                  onChange={(e) => setTraffic(Number(e.target.value))}
                  className="w-full mt-2 accent-purple-500"
                />
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Conversion Rate (%)</label>
                <Input 
                  type="number" 
                  value={conversionRate} 
                  onChange={(e) => setConversionRate(Number(e.target.value))} 
                  className="bg-slate-700 border-slate-600 text-white"
                />
                <input
                  type="range"
                  min="0.1"
                  max="10"
                  step="0.1"
                  value={conversionRate}
                  onChange={(e) => setConversionRate(Number(e.target.value))}
                  className="w-full mt-2 accent-pink-500"
                />
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Average Order Value ($)</label>
                <Input 
                  type="number" 
                  value={averageOrder} 
                  onChange={(e) => setAverageOrder(Number(e.target.value))} 
                  className="bg-slate-700 border-slate-600 text-white"
                />
                <input
                  type="range"
                  min="10"
                  max="1000"
                  step="10"
                  value={averageOrder}
                  onChange={(e) => setAverageOrder(Number(e.target.value))}
                  className="w-full mt-2 accent-cyan-500"
                />
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Average Customer Lifetime Value ($)</label>
                <Input 
                  type="number" 
                  value={lifetimeValue} 
                  onChange={(e) => setLifetimeValue(Number(e.target.value))} 
                  className="bg-slate-700 border-slate-600 text-white"
                />
                <input
                  type="range"
                  min="100"
                  max="5000"
                  step="100"
                  value={lifetimeValue}
                  onChange={(e) => setLifetimeValue(Number(e.target.value))}
                  className="w-full mt-2 accent-purple-500"
                />
              </div>
            </div>
          </div>
          
          <div className="w-full lg:w-1/2">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-8 border border-slate-700 shadow-xl h-full">
              <h3 className="text-2xl font-bold mb-6 text-white">Your Results</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-gray-300 mb-2">Annual Traditional Cost</h4>
                  <motion.div 
                    className="text-4xl font-bold text-white font-mono"
                    key={annualTraditional}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    ${annualTraditional.toLocaleString()}
                  </motion.div>
                  <div className="w-full bg-slate-700 rounded-full h-2 mt-2">
                    <motion.div 
                      className="bg-pink-500 h-2 rounded-full" 
                      initial={{ width: 0 }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 0.5 }}
                    ></motion.div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-gray-300 mb-2">SociLume Cost</h4>
                  <motion.div 
                    className="text-4xl font-bold text-white font-mono"
                    key={annualFloat}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    ${annualFloat.toLocaleString()}
                  </motion.div>
                  <div className="w-full bg-slate-700 rounded-full h-2 mt-2">
                    <motion.div 
                      className="bg-cyan-500 h-2 rounded-full" 
                      initial={{ width: 0 }}
                      animate={{ width: `${(annualFloat / annualTraditional) * 100}%` }}
                      transition={{ duration: 0.5 }}
                    ></motion.div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-gray-300 mb-2">Projected Annual Savings</h4>
                  <motion.div 
                    className="text-4xl font-bold text-green-400 font-mono"
                    key={savings}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    ${savings.toLocaleString()}
                  </motion.div>
                </div>
                
                <div>
                  <h4 className="text-gray-300 mb-2">Estimated Annual Revenue</h4>
                  <motion.div 
                    className="text-4xl font-bold text-purple-400 font-mono"
                    key={annualRevenue}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    ${annualRevenue.toLocaleString()}
                  </motion.div>
                </div>
                
                <div>
                  <h4 className="text-gray-300 mb-2">Total Customer Lifetime Value</h4>
                  <motion.div 
                    className="text-4xl font-bold text-amber-400 font-mono"
                    key={totalValue}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    ${totalValue.toLocaleString()}
                  </motion.div>
                </div>
                
                <Button 
                  className="w-full bg-gradient-to-r from-pink-500 to-cyan-500 text-white py-6 text-lg flex items-center justify-center gap-2"
                  onClick={handleDownload}
                >
                  <Download size={18} />
                  Download Report
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-12 text-center max-w-3xl mx-auto">
          <p className="text-gray-300 text-lg">
            Imagine reinvesting ${savings.toLocaleString()} into marketing or staff training. 
            Our expert team will build you a SociLume site that turns your website from a cost center into a growth engine.
          </p>
        </div>
      </div>
      
      {/* Email Capture Modal for Report Download */}
      <div 
        ref={modalRef}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center hidden"
      >
        <div className="bg-slate-800 border border-slate-700 p-8 rounded-xl max-w-md w-full">
          <h3 className="text-2xl font-bold text-white mb-4">Get Your ROI Report</h3>
          <p className="text-gray-300 mb-6">Enter your email and we'll send your personalized ROI report.</p>
          
          <form onSubmit={handleSubmitEmail} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
              <Input 
                type="email" 
                id="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
                required
              />
            </div>
            
            <div className="flex space-x-3">
              <Button 
                type="submit" 
                className="flex-1 bg-gradient-to-r from-pink-500 to-cyan-500 text-white"
              >
                Send Report
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={closeModal}
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default RevenueCalculator;
