
import { useState } from 'react';

const Templates = () => {
  const [selectedFilter, setSelectedFilter] = useState('all');
  
  const filters = [
    { id: 'all', label: 'All Templates' },
    { id: 'business', label: 'Business' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'ecommerce', label: 'E-Commerce' },
    { id: 'landing', label: 'Landing Pages' },
  ];
  
  const templates = [
    {
      id: 1,
      name: "Elegance",
      category: "business",
      image: "https://images.unsplash.com/photo-1487958449943-2429e8be8625",
      tags: ["Minimal", "Corporate", "Light"]
    },
    {
      id: 2,
      name: "Portfolio Pro",
      category: "portfolio",
      image: "https://images.unsplash.com/photo-1517022812141-23620dba5c23",
      tags: ["Creative", "Gallery", "Artist"]
    },
    {
      id: 3,
      name: "ShopStyle",
      category: "ecommerce",
      image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5",
      tags: ["Shop", "Fashion", "Modern"]
    },
    {
      id: 4,
      name: "LaunchPad",
      category: "landing",
      image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1",
      tags: ["Clean", "App", "SaaS"]
    },
    {
      id: 5,
      name: "CreativeFlow",
      category: "portfolio",
      image: "https://images.unsplash.com/photo-1483058712412-4245e9b90334",
      tags: ["Designer", "Dark", "Bold"]
    },
    {
      id: 6,
      name: "BizGrid",
      category: "business",
      image: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7",
      tags: ["Grid", "Services", "Corporate"]
    },
  ];
  
  const filteredTemplates = selectedFilter === 'all' 
    ? templates 
    : templates.filter(template => template.category === selectedFilter);

  return (
    <section id="templates" className="py-24 bg-navy-50 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-navy-800">Templates Gallery</h2>
          <p className="text-lg text-navy-600 max-w-2xl mx-auto">
            Browse our collection of premium templates ready for customization
          </p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <button
              key={filter.id}
              className={`px-5 py-2 rounded-full transition-all duration-300 ${
                selectedFilter === filter.id 
                  ? 'bg-navy-800 text-white shadow-lg' 
                  : 'bg-white text-navy-600 hover:bg-navy-100'
              }`}
              onClick={() => setSelectedFilter(filter.id)}
            >
              {filter.label}
            </button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {filteredTemplates.map((template) => (
            <div 
              key={template.id} 
              className="group relative h-80 tilt-card overflow-hidden rounded-xl shadow-lg"
            >
              <img 
                src={template.image} 
                alt={template.name} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-900/90 to-transparent flex flex-col justify-end p-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <h3 className="text-2xl font-bold text-white mb-2">{template.name}</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  {template.tags.map((tag, idx) => (
                    <span key={idx} className="text-xs bg-white/20 text-white px-2 py-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
                <button className="floating-button bg-gold-400 hover:bg-gold-500 text-navy-800 px-4 py-2 rounded-lg font-medium">
                  Preview Template
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Templates;
