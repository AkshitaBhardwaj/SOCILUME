
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import DarkHero from '../components/DarkHero';
import RevenueCalculator from '../components/RevenueCalculator';
import Templates from '../components/Templates';
import HowItWorks from '../components/HowItWorks';
import Pricing from '../components/Pricing';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import { useToast } from "@/hooks/use-toast";

const DarkMode = () => {
  const { toast } = useToast();
  const [showStats, setShowStats] = useState(false);

  useEffect(() => {
    // Welcome toast
    setTimeout(() => {
      toast({
        title: "Welcome to SociLume Dark Mode",
        description: "Explore how we can build your custom site with neon flair in just one week.",
        variant: "default"
      });
    }, 2000);
    
    // Apply dark styles to body
    document.body.classList.add('bg-slate-900');
    
    // Show stats after page load
    setTimeout(() => {
      setShowStats(true);
    }, 3000);
    
    return () => {
      document.body.classList.remove('bg-slate-900');
    };
  }, [toast]);

  return (
    <motion.div
      className="overflow-hidden bg-slate-900 text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Custom cursor effect */}
      <div id="cursor-glow" className="hidden lg:block fixed w-64 h-64 pointer-events-none z-50 rounded-full bg-gradient-to-r from-pink-500/20 to-cyan-500/20 blur-3xl transform -translate-x-1/2 -translate-y-1/2"></div>
      
      {/* Stats panel */}
      {showStats && (
        <motion.div 
          className="fixed top-24 right-8 z-40 neo-glass-card rounded-xl overflow-hidden shadow-xl"
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ type: "spring", damping: 12 }}
        >
          <div className="p-4">
            <h3 className="font-bold text-white text-center mb-2 text-sm">Our Impact This Month</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-300">Sites Built:</span>
                <StatsCounter end={42} duration={2} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-300">Avg. Build Time:</span>
                <div className="flex items-center">
                  <StatsCounter end={6} duration={1.5} />
                  <span className="text-xs text-cyan-300 ml-1">days</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-300">Client Savings:</span>
                <div className="flex items-center">
                  <span className="text-xs text-green-400">$</span>
                  <StatsCounter end={946750} duration={3} formatAsNumber />
                </div>
              </div>
            </div>
          </div>
          <div className="px-4 py-2 bg-gradient-to-r from-pink-500/30 to-purple-500/30 text-center">
            <span className="text-[10px] text-white/90">Based on real client data</span>
          </div>
        </motion.div>
      )}
      
      {/* Sticky CTA button */}
      <div className="fixed bottom-8 right-8 z-50 hanging-button">
        <motion.a 
          href="/contact" 
          className="bg-gradient-to-r from-[#FF3366] to-[#33FFFF] text-white shadow-lg px-6 py-3 rounded-full font-medium flex items-center space-x-2 transition-all duration-300 hover:shadow-xl border border-white/10"
          whileHover={{
            scale: 1.05,
            boxShadow: '0 0 15px rgba(255, 51, 102, 0.5)'
          }}
        >
          <span>Get Started</span>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 5.25l-7.5 7.5-7.5-7.5m15 6l-7.5 7.5-7.5-7.5" />
          </svg>
        </motion.a>
      </div>
      
      <Navbar />
      <DarkHero />
      <RevenueCalculator />
      <Templates />
      <HowItWorks />
      <Pricing />
      <Contact />
      <Footer />
      
      {/* Custom cursor script - must be added at the end of the body */}
      <script dangerouslySetInnerHTML={{
        __html: `
          document.addEventListener('mousemove', (e) => {
            const cursor = document.getElementById('cursor-glow');
            if (cursor) {
              cursor.style.left = e.clientX + 'px';
              cursor.style.top = e.clientY + 'px';
            }
          });
        `
      }} />
    </motion.div>
  );
};

// Stats counter component with animation
const StatsCounter = ({ 
  end, 
  duration = 2,
  formatAsNumber = false
}: { 
  end: number; 
  duration?: number;
  formatAsNumber?: boolean;
}) => {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    let startTime: number;
    let animationFrame: number;
    
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / (duration * 1000), 1);
      const currentCount = Math.floor(progress * end);
      
      setCount(currentCount);
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    
    animationFrame = requestAnimationFrame(animate);
    
    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration]);
  
  return (
    <span className="font-mono text-xs font-bold text-white">
      {formatAsNumber ? count.toLocaleString() : count}
    </span>
  );
};

export default DarkMode;
