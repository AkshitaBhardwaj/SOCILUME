
import { useEffect } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Features from '../components/Features';
import HowItWorks from '../components/HowItWorks';
import Pricing from '../components/Pricing';
import Templates from '../components/Templates';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import { useToast } from "@/hooks/use-toast";
import { motion, useAnimation } from 'framer-motion';

const Index = () => {
  const { toast } = useToast();
  const controls = useAnimation();

  useEffect(() => {
    // Simulate page load complete
    controls.start({
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    });

    // Welcome toast
    setTimeout(() => {
      toast({
        title: "Welcome to SociLume",
        description: "Explore our site builder for premium brands on a budget.",
      });
    }, 2000);
  }, [controls, toast]);

  return (
    <motion.div
      className="overflow-x-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={controls}
    >
      {/* Sticky CTA button */}
      <div className="fixed bottom-8 right-8 z-50 hanging-button">
        <a href="/contact" className="bg-gold-400 text-navy-800 hover:bg-gold-500 shadow-lg px-6 py-3 rounded-full font-medium flex items-center space-x-2 transition-all duration-300 hover:shadow-xl">
          <span>Contact Us</span>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 5.25l-7.5 7.5-7.5-7.5m15 6l-7.5 7.5-7.5-7.5" />
          </svg>
        </a>
      </div>
      
      <Navbar />
      <Hero />
      <Features />
      <HowItWorks />
      <Pricing />
      <Templates />
      <Contact />
      <Footer />
    </motion.div>
  );
};

export default Index;
