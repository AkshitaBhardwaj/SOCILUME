
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			fontFamily: {
				sans: ['Inter', 'sans-serif'],
				montserrat: ['Montserrat', 'sans-serif'],
			},
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				navy: {
					DEFAULT: '#1A1F2C',
					50: '#F2F3F5',
					100: '#E5E7EA',
					200: '#C5C9D1',
					300: '#A5ABB7',
					400: '#858D9E',
					500: '#667085',
					600: '#4D566A',
					700: '#333A4F',
					800: '#1A1F2C',
					900: '#0D1015',
				},
				gold: {
					DEFAULT: '#E2C792',
					50: '#FCF9F2',
					100: '#F9F4E6',
					200: '#F3E9CC',
					300: '#EDDEB3',
					400: '#E2C792',
					500: '#D7B170',
					600: '#C49B4E',
					700: '#A9813A',
					800: '#8E6C31',
					900: '#735827',
				},
				coral: {
					DEFAULT: '#FF7F5C', 
					50: '#FFEEEA',
					100: '#FFDCD5',
					200: '#FFB9AA',
					300: '#FF9C80',
					400: '#FF7F5C',
					500: '#FF5C33',
					600: '#FF3A09',
					700: '#D42C00',
					800: '#A12200',
					900: '#6E1700',
				},
				azure: {
					DEFAULT: '#8BBBD9',
					50: '#F0F6FB',
					100: '#E1EDF6',
					200: '#C3DBED',
					300: '#A5C9E3',
					400: '#8BBBD9',
					500: '#63A3CA',
					600: '#3C8BB9',
					700: '#2F6D91',
					800: '#234F69',
					900: '#183141',
				},
				primary: {
					DEFAULT: '#1A1F2C',
					foreground: '#FFFFFF'
				},
				secondary: {
					DEFAULT: '#E2C792',
					foreground: '#1A1F2C'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: '#8BBBD9',
					foreground: '#FFFFFF'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				"accordion-down": {
					from: { height: '0' },
					to: { height: 'var(--radix-accordion-content-height)' },
				},
				"accordion-up": {
					from: { height: 'var(--radix-accordion-content-height)' },
					to: { height: '0' },
				},
				float: {
					'0%, 100%': { transform: 'translateY(0)' },
					'50%': { transform: 'translateY(-10px)' },
				},
				hang: {
					'0%, 100%': { transform: 'rotate(-1deg)' },
					'50%': { transform: 'rotate(1deg)' },
				},
				fadeIn: {
					'0%': { opacity: '0', transform: 'translateY(20px)' },
					'100%': { opacity: '1', transform: 'translateY(0)' },
				},
				fadeInLeft: {
					'0%': { opacity: '0', transform: 'translateX(-20px)' },
					'100%': { opacity: '1', transform: 'translateX(0)' },
				},
				fadeInRight: {
					'0%': { opacity: '0', transform: 'translateX(20px)' },
					'100%': { opacity: '1', transform: 'translateX(0)' },
				},
			},
			animation: {
				"accordion-down": "accordion-down 0.2s ease-out",
				"accordion-up": "accordion-up 0.2s ease-out",
				"float": "float 3s ease-in-out infinite",
				"hang": "hang 3s ease-in-out infinite",
				"fade-in": "fadeIn 0.7s ease-out forwards",
				"fade-in-left": "fadeInLeft 0.7s ease-out forwards",
				"fade-in-right": "fadeInRight 0.7s ease-out forwards",
			},
		},
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
